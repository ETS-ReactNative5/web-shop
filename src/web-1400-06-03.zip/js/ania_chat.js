window.AniaChatInit = function(){
    if(!window.AniaChatId)
        return;
        //var url='http://localhost:3000/ChatApi/chatSettings';
        var url='https://siteapi.sarvapps.ir/ChatApi/chatSettings';
        var callback = function(response){
            create(response[0]||{});    
        }
        var error = function(err){
            alert(2)
        }
    server(url,{AniaChatId:window.AniaChatId,User:1,get:1},callback,error);
    

}
window.AniaChatSendBtn = function(box,content){
    setChat();
}
window.AniaChatClickBox = function(box,content){
    if(content.className.indexOf("ania-chat-content-show") == -1){
        getChat();
        window.ania_chat_interval = setInterval(function() {
            getChat();
        }, 8000);   
    }else{
        clearInterval(window.ania_chat_interval);
    }
    content.classList.toggle("ania-chat-content-show");

    

    
}
function create(settings){
    window.ania_chat_interval = "";
    var parentOfImg = document.createElement("div");
    var position = settings.placeFilter||"bottom-right";

    parentOfImg.className = "ania-chat-box "+position+"";
    parentOfImg.id = "ania-chat-box";
    var img = document.createElement("img");
    img.src= settings.picFilter ||"https://sarvapps.ir/help.png";
    img.id = "ania-chat-logo";
    img.className="ania-chat-logo";
    var body = document.createElement("div");
    var content = document.createElement("div");
    content.className = "ania-chat-content "+position+"";
    content.id= "ania-chat-content";
    var textArea = document.createElement("textarea");    
    textArea.placeholder=settings.placeHolder || "پیام خود را بنویسید";
    textArea.id = "ania-chat-text";
    textArea.onkeypress=function(){
        var key = window.event.keyCode;
    
        // If the user has pressed enter
        if (key === 13) {
            setChat();
            return false;
        }
        else {
            return true;
        }
    }
    var headerBox = document.createElement("div");
    headerBox.className = "ania-chat-header";
    let topText = settings.topText || 'سوالی دارید ؟ \n با ما صحبت کنید ...';
    headerBox.innerHTML="<div style='display:flex;justify-content: space-between;'><div><div style='color:#fff;font-size:14px;white-space:pre-wrap'>"+topText+"</div></div><div><img src='https://sarvapps.ir/close_icon.png' style='width:20px;cursor:pointer' id='ania-chat-close'  /></div></div>";
    var centerBox = document.createElement("div");
    centerBox.className = "ania-chat-center";
    centerBox.id = "ania-chat-center";
    centerBox.innerHTML="";
    var footerBox = document.createElement("div");
    footerBox.className = "ania-chat-footer";
    var sendBtn = document.createElement("button");
    sendBtn.style.backgroundColor="transparent";

    sendBtn.innerHTML="<img src='https://sarvapps.ir/send.png' style='width:40px' />";

    footerBox.appendChild(textArea)
    footerBox.appendChild(sendBtn)

    content.appendChild(headerBox);
    content.appendChild(centerBox);

    content.appendChild(footerBox);

    parentOfImg.appendChild(img);
    body.appendChild(parentOfImg)
    body.appendChild(content);

    
    sendBtn.addEventListener("click",function(){
      window.AniaChatSendBtn()
    })
    document.getElementsByTagName("body")[0].appendChild(body);

    var close = document.getElementById("ania-chat-close");
    
    close.addEventListener("click",function(){
        window.AniaChatClickBox(parentOfImg,content)
      })
    parentOfImg.addEventListener("click",function(){
      window.AniaChatClickBox(parentOfImg,content)
    })
}
function textAreaChange() {
    var key = window.event.keyCode;

    // If the user has pressed enter
    if (key === 13) {
        setChat();
        return false;
    }
    else {
        return true;
    }
}
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
  function getChat(){
    var ania_chat_id = getCookie("ania_chat_id");
    //var url='http://localhost:3000/ChatApi/getChat';
    var url='https://siteapi.sarvapps.ir/ChatApi/getChat';

    
    var centerBox = document.getElementById("ania-chat-center");

    var callback = function(response){
        if(response[0]){
            var resp = response[0];
            var details="";
            if(resp.End){
                document.cookie = "ania_chat_id=";
                centerBox.innerHTML="";
            }else{
                for(var i=0;i<resp.chats_detail.length;i++){
                    var color = resp.chats_detail[i].userSend ? '#c2ff94ba' : '#fff';
                    if(resp.chats_detail[i].userSend){
                        var icon = resp.chats_detail[i].read ? "<img src='https://sarvapps.ir/read.png' style='width:16px' />" :  "<img src='https://sarvapps.ir/unread.png' style='width:16px;opacity:0.3' />"
                        details+="<p style='float:right;clear:both;white-space:pre-wrap;background:"+color+";margin-top:5px !important;border-radius:10px;padding:8px;color:#000;font-size:13px'><span>"+resp.chats_detail[i].text+"</span><br/><sapn>"+icon+"</span><sapn style='font-size:10px;color:#b9b9b9;padding-right:3px'>"+resp.chats_detail[i].TodayTime+"</span></p>"

                    }
                    else
                        details+="<p style='float:left;clear:both;white-space:pre-wrap;background:"+color+";text-align:left;margin-top:5px !important;border-radius:10px;padding:8px;color:#000;font-size:13px'><span>"+resp.chats_detail[i].text+"</span><br/><sapn style='font-size:10px;color:#b9b9b9'>"+resp.chats_detail[i].TodayTime+"</span></p>"
        
                }
                var icon = resp.read ? "<img src='https://sarvapps.ir/read.png' style='width:16px' />" :  "<img src='https://sarvapps.ir/unread.png' style='width:16px;opacity:0.3' />"

                centerBox.innerHTML = "<p style='float:right;clear:both;white-space:pre-wrap;background:#c2ff94ba;border-radius:10px;padding:8px;color:#000;font-size:13px'><span>"+resp.text+"</span><br/><sapn>"+icon+"</span><sapn style='font-size:10px;color:#b9b9b9;padding-right:3px'>"+resp.TodayTime+"</span></p>"+details;
                centerBox.scrollTop = centerBox.scrollHeight;
            }
            
        }
        
    }
    var error = function(err){
        alert(2)

    }
    if(ania_chat_id){
        server(url,{_id:ania_chat_id,code:window.AniaChatId,User:1},callback,error);

    }

  }
  function setChat(){
    var value = document.getElementById("ania-chat-text").value;
    if(!value)
        return;
    document.getElementById("ania-chat-text").value = "";
    var ania_chat_id = getCookie("ania_chat_id");
    //var url='http://localhost:3000/ChatApi/setChat';
    var url='https://siteapi.sarvapps.ir/ChatApi/setChat';

    var callback = function(response){
        if(!ania_chat_id){
            ania_chat_id = response.ops[0]._id;
            document.cookie = "ania_chat_id="+ania_chat_id+"";
        }
        getChat();
    }
    var error = function(err){
        alert(2)

    }
    server(url,{_id:ania_chat_id ? ania_chat_id : null,value:value,userSend:1,code:window.AniaChatId},callback,error);
  }
  function server(url,param,callback,error){

    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);

    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("Access-Control-Allow-Origin","*");
    xhr.setRequestHeader("Access-Control-Allow-Methods","GET, POST, PUT, DELETE, PATCH, OPTIONS");
    xhr.setRequestHeader("Access-Control-Allow-Headers","x-requested-with, Content-Type, origin, authorization, accept, client-security-token");

    xhr.onreadystatechange = function() { // Call a function when the state changes.
        if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
            try{
                var resp = JSON.parse(this.response).result;
                callback(resp)
            }
            catch(error){

            }
        }
    }
    xhr.send(JSON.stringify(param));
  }
