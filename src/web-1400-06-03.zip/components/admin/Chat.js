import React, { Component } from 'react';
import axios from 'axios'
import { BrowserRouter, Route, withRouter, Redirect } from 'react-router-dom'
import Dashboard from './Dashboard.js'
import './Dashboard.css'
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import ReactTable from "react-table";


import 'primeicons/primeicons.css';
import Server from './../Server.js'
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { SelectButton } from 'primereact/selectbutton';
import { connect } from 'react-redux';
import { Dropdown } from 'primereact/dropdown';
import { Loader } from 'rsuite';
import { Alert } from 'rsuite';
import { Toast } from 'primereact/toast';
import GoogleMapReact from 'google-map-react';
import { Checkbox } from 'primereact/checkbox';
import './DataTableDemo.css';
const FilterItems = [
    { label: 'همه', value: 'All' },
    { label: 'جاری', value: "1" },

    { label: 'پایان یافته', value: "2" }



];
let ania_chat_interval =null,
    ania_chat_interval2 = null;
class Chat extends React.Component {
    constructor(props) {
        super(props);
        this.Server = new Server();
        this.state = {
            layout: 'list',
            dashList: (this.props && this.props.location && this.props.location.state && this.props.location.state.list) ? this.props.location.state.list : [],
            dashData: (this.props && this.props.location && this.props.location.state && this.props.location.state.data) ? this.props.location.state.data : [],
            NewFactors: (this.props && this.props.location && this.props.location.state && this.props.location.state.NewFactors) ? this.props.location.state.NewFactors : null,
            NewUsers: (this.props && this.props.location && this.props.location.state && this.props.location.state.NewUsers) ? this.props.location.state.NewUsers : null,
            ChatSelected: {},
            Filter: "1",
            url: this.Server.getUrl()

        }
        this.toast = React.createRef();
        this.selectChat = this.selectChat.bind(this);
        this.EndChat = this.EndChat.bind(this);
        this.itemTemplate = this.itemTemplate.bind(this);
        this.onHideDialog = this.onHideDialog.bind(this);
        this.SetAnswer = this.SetAnswer.bind(this);
        this.getCode = this.getCode.bind(this);


    }

    componentDidMount() {
        let param = {
            token: localStorage.getItem("api_token"),
        };
        let that = this;
        this.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            that.setState({
                loading: 0
            })
            that.setState({
                username: response.data.authData.username,
                shopId: response.data.authData.shopId,
                name: response.data.authData.name || ""
            })


            that.getShop();


        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("MainApi/checktoken", param, SCallBack, ECallBack)
    }
    getShop() {
        let that = this;
        that.Server.send("AdminApi/ShopInformation", { ShopId: this.state.shopId }, function (response) {
            that.setState({
                tokenId: response.data.result[0]?.tokenId
            })
            that.getCode();


        }, function (error) {
        })
    }
    getCode() {
        let that = this;
        that.Server.send("AdminApi/getSettings", {}, function (response) {
            that.setState({
                code: response.data.result[0] ? response.data.result[0].ChatId : '',
            })
            that.getChat(null, that.state.Filter);
            ania_chat_interval2 = setInterval(function () {
                that.getChat(null, that.state.Filter);
            }, 10000);



        }, function (error) {
        })
    }


    getChat(_id, Filter) {
        let param = {
            token: localStorage.getItem("api_token"),
            sort: { "_id": -1 },
            _id: _id,
            User:0,
            End: Filter,
            code: this.state.tokenId || this.state.code
        };
        let that = this;
        this.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            if (_id) {
                that.setState({
                    loading: 0,
                    ChatSelected: response.data.result[0]
                })


            } else {
                that.setState({
                    loading: 0,
                    GridData: response.data.result
                })
            }




        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("ChatApi/getChat", param, SCallBack, ECallBack)

    }
    selectChat(itemSelected) {
        let that = this;
        clearInterval(ania_chat_interval2);

        ania_chat_interval = setInterval(function () {
            if(that.state.ChatSelected._id)
                that.getChat(that.state.ChatSelected._id);
            else    
                clearInterval(ania_chat_interval);

        }, 10000);
        this.setState({
            visibleDialog: true,
            ChatSelected: itemSelected
        })
        this.getChat(that.state.ChatSelected._id);

    }
    EndChat(itemSelected) {
        let _id = itemSelected._id;
        let param = {
            token: localStorage.getItem("api_token"),
            _id: _id,
            code: this.state.code
        };
        let that = this;
        this.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            that.setState({
                loading: 0
            })
            that.getChat();





        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("ChatApi/EndChat", param, SCallBack, ECallBack)
        return false;

    }
    itemTemplate(car, layout) {
        if (!car)
            return (
                <div className="p-col-12 p-md-3">
                    <div></div>
                </div>
            );

        if (layout === 'list') {
            return (
                <div className="row" >
                    <div className="col-lg-12 " >
                        <div className="row" style={{ margin: 20 }}>

                            <div className="col-lg-9 col-12 yekan" style={{ cursor: 'pointer', textAlign: "right", backgroundColor: '#f5f5f54a', padding: 10, borderRadius: 10 }} onClick={() => { this.selectChat(car) }} >
                                <p className="yekan" >{car.TodayTime} : {car.TodayDate}</p>

                                <p className="yekan" style={{ fontSize: 25, color: 'blue', whiteSpace: 'pre-wrap' }}>
                                {car.read ?
                                <img src='https://sarvapps.ir/read.png' style={{width:16}} />

                                :
                                <img src='https://sarvapps.ir/unread.png' style={{width:16}} />
                                }
                                    <span>{car.text}</span>
                                
                                
                                </p>
                                
                                
                                
                                {car.chats_detail &&
                                    <span>{car.chats_detail[car.chats_detail.length - 1]?.text}</span>
                                }



                            </div>
                            <div className="col-lg-3 col-12">
                                {car.End ?
                                    <div>
                                        <p className="yekan" style={{ color: 'red' }}>پایان یافته</p>

                                    </div>
                                    :
                                    <div>

                                        <button className="btn btn-danger yekan" onClick={() => { this.EndChat(car) }} style={{ marginTop: "5px", marginBottom: "5px", float: 'left' }}>پایان گفتگو </button>

                                    </div>
                                }
                            </div>




                        </div>
                        <hr />
                    </div>

                </div>
            );
        }
        if (layout === 'grid') {
            return (
                <div className="p-col-12 p-md-3">
                    <div>{car.brand}</div>
                </div>
            );
        }
    }

    onHideDialog(event) {
        clearInterval(ania_chat_interval);
        let that = this;
        ania_chat_interval2 = setInterval(function () {

            that.getChat(null, that.state.Filter);
        }, 10000);

        this.getChat(null, that.state.Filter);

        this.setState({
            visibleDialog: false,
            ChatSelected: {}
        });
    }
    SetAnswer() {
        let param = {
            token: localStorage.getItem("api_token"),
            sort: { TodayDate_C: -1 },
            _id: this.state.ChatSelected._id,
            value: this.state.answer,
            userSend: 0,
            code: this.state.code
        };
        let that = this;
        this.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            that.setState({
                loading: 0
            })
            that.toast.current.show({ severity: 'success', summary: <div>پاسخ با موفقیت ارسال شد</div>, life: 8000 });
            that.getChat(that.state.ChatSelected._id);
            //that.onHideDialog();


        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("ChatApi/setChat", param, SCallBack, ECallBack)
    }

    render() {


        return (
            <div style={{ direction: 'rtl' }}>


                {this.state.loading == 1 &&
                    <div style={{ position: 'fixed', zIndex: 2000, top: 10, left: '50%', padding: '2px 20px' }}>
                        <Loader content="" className="yekan" />
                    </div>
                }
                <Toast ref={this.toast} position="top-left" style={{ fontFamily: 'YekanBakhFaBold', textAlign: 'right' }} />

                <div className="row justify-content-center">

                    <div className="col-12" >
                        <div className="row" style={{alignItems:'center'}} >
                            <div className="col-9" >
                                <div style={{ textAlign: 'right', marginBottom: 10 }}>
                                    <SelectButton value={this.state.Filter} options={FilterItems} style={{ fontFamily: 'Yekan' }} className="yekan" onChange={(e) => { this.setState({ Filter: e.value }); this.getChat(null, e.value) }}></SelectButton>

                                </div>

                            </div>
                            <div className="col-3" >
                                <div style={{ textAlign: 'right', marginBottom: 10 }}>

                                    <button className="btn btn-info yekan" onClick={() => { this.getChat(null, this.state.Filter) }} style={{ marginTop: "5px", marginBottom: "5px" }}><i className="fas fa-sync" /></button>
                                </div>

                            </div>
                        </div>


                        <DataView value={this.state.GridData} layout={this.state.layout} paginator={true} rows={10} itemTemplate={this.itemTemplate}></DataView>
                    </div>



                </div>
                <Dialog style={{ width: '60vw' }} header={this.state.selectedId ? "اصلاح" : "ثبت درخواست"} visible={this.state.visibleDialog} onHide={() => { this.onHideDialog() }} maximizable={true} maximized={true}>

                    <div className="row">
                        <div className="col-lg-12 " >
                            <div className="row" style={{ margin: 20 }}>

                                <div className="col-lg-12 col-12 yekan" style={{ textAlign: "right", padding: 10, borderRadius: 10 }}>
                                    <p className="yekan" >{this.state.ChatSelected.TodayTime} : {this.state.ChatSelected.TodayDate}</p>

                                    <p className="yekan" style={{ fontSize: 25, color: 'blue' }}>
                                    {this.state.ChatSelected.read ?
                                <img src='/read.png' style={{width:16}} />

                                :
                                <img src='/unread.png' style={{width:16}} />
                                }
                                        {this.state.ChatSelected.text}</p>


                                </div>


                                <div className="col-9" style={{ textAlign: 'right' }}>
                                    {this.state.ChatSelected.chats_detail && this.state.ChatSelected.chats_detail.map((v, i) => {
                                        return (
                                            <div style={{ borderBottom: '1px solid #eee', marginBottom: 20 }}>
                                                {v.userSend ?
                                                    <p className="yekan" style={{ textAlign: 'left', color: '#aba8a8' }}>{v.TodayTime} : {v.TodayDate}</p>
                                                    :
                                                    <p className="yekan" style={{ textAlign: 'right', color: '#aba8a8' }}>{v.TodayTime} : {v.TodayDate}</p>
                                                }
                                                {v.userSend ?
                                                    <p className="yekan" style={{ whiteSpace: 'pre-wrap', fontSize: 19, color: '#28A52D', textAlign: 'left' }}>{v.text}</p>
                                                    :
                                                    <p className="yekan" style={{ whiteSpace: 'pre-wrap', fontSize: 19, textAlign: 'right' }}>
                                                         {v.read ?
                                <img src='/read.png' style={{width:16}} />

                                :
                                <img src='/unread.png' style={{width:16}} />
                                }
                                {v.text}</p>
                                                }

                                            </div>
                                        )
                                    })
                                    }
                                </div>
                                {!this.state.ChatSelected.End &&
                                    <div className="col-lg-12 col-12 yekan" style={{ textAlign: "center" }}>
                                        <div className="group">
                                            <textarea className="form-control irsans" style={{ height: 200 }} autoComplete="off" type="text" value={this.state.answer} name="answer" onChange={(event) => this.setState({ answer: event.target.value })} required="true" ></textarea>
                                            <label>پاسخ</label>
                                        </div>
                                        <div style={{ textAlign: 'right' }}>
                                            <button className="btn btn-primary irsans" onClick={this.SetAnswer} style={{ width: "200px", marginTop: "20px", marginBottom: "20px" }}> اعمال </button>
                                        </div>
                                    </div>

                                }


                            </div>
                            <hr />
                        </div>

                    </div>
                </Dialog>

            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        username: state.username
    }
}
export default withRouter(
    connect(mapStateToProps)(Chat)
);
