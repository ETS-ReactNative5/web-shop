import React, { Component } from 'react';
import axios from 'axios'
import { BrowserRouter, Route, withRouter, Redirect } from 'react-router-dom'
import Dashboard from './Dashboard.js'
import './report.css'
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import ReactTable from "react-table";


import 'primeicons/primeicons.css';
import Server from './../Server.js'
import { io } from "socket.io-client";
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { AutoComplete } from 'primereact/autocomplete';

import { connect } from 'react-redux';
import { Dropdown } from 'primereact/dropdown';
import { Loader } from 'rsuite';
import { Alert } from 'rsuite';
import { Checkbox } from 'primereact/checkbox';
import { Fieldset } from 'primereact/fieldset';
import DatePicker from 'react-datepicker2';
import { ComponentToPrint } from '../ComponentToPrint.js';
import ReactToPrint, { PrintContextConsumer } from 'react-to-print';
var socket;

class Show_Reports extends React.Component {
  constructor(props) {
    super(props);
    this.Server = new Server();
    this.state = {
      loading: 0,
      Filters:[],
      output:'',
      legend: " فیلتر گزارش شماره " + this.props.number,
      MainShopInfo:{}
      

    }
    socket = io(this.Server.getAbsoluteUrl());

    this.generateExcel = this.generateExcel.bind(this);
    this.showReports = this.showReports.bind(this);
    this.showReportsDetail = this.showReportsDetail.bind(this);    
    this.Clear = this.Clear.bind(this);
    this.sortTable = this.sortTable.bind(this);
    
  }
  GetFilters() {
    let that = this;
    debugger;

    let param = {
      token: localStorage.getItem("api_token"),
      number:this.props.number
    };
    this.setState({
      loading: 1
    })
    let SCallBack = function (response) {

      let FilterIds=[];
      that.setState({
        method:response.data.result[0].method,
        number:that.props.number
      })
      for(let item of response.data.result[0].Filters){
        FilterIds.push(item.id);
      }
      that.Server.send("AdminApi/GetFilters", {_id:FilterIds}, function (response) {

        let ShowParam=[];
        let ComboParam = [];
        let AutoCompleteParam = [];
        let count=0;
        for(let item of response.data.result){
          ShowParam.push({name:item.latinName,type:item.type});
          if(item.type=="3"){
            ComboParam.push({DBTableFieldLabel:item.DBTableFieldLabel,DBTableFieldValue:item.DBTableFieldValue,DbTableName:item.DbTableName,FId:item.FId})
          }  
          if(item.type=="4"){
            item.index = count;
            AutoCompleteParam.push({index:count,latinName:item.latinName,DBTableFieldLabel:item.DBTableFieldLabel,DBTableFieldValue:item.DBTableFieldValue,DbTableName:item.DbTableName,FId:item.FId})
            count++;
          }
        }
        that.setState({
          loading: 0,
          Filters:response.data.result,
          ShowParam:ShowParam,
          ComboParam:ComboParam,
          AutoCompleteParam:AutoCompleteParam
        })
        if(ComboParam.length > 0)
          that.getCombo();
      }, function (error) {
        Alert.error('عملیات انجام نشد', 5000);
        that.setState({
          loading: 0
        })
      })
      
      

    };
    let ECallBack = function (error) {
      Alert.error('عملیات انجام نشد', 5000);
      that.setState({
        loading: 0
      })
    }
    this.Server.send("AdminApi/GetFilters", param, SCallBack, ECallBack)
  }
  sortTable(event) {
    var table, rows, switching, i, x, y, shouldSwitch;
    let cellIndex = -1;
    if(event.target.tagName == "TD" && event.target.className == "header-td")
      cellIndex = event.target.cellIndex
    if(cellIndex == -1)
      return;
    table = x=event.target.parentElement.parentElement.parentElement;
    let sort = 1;
    if(!isNaN(parseInt(event.target.getAttribute("sort"))))
      sort = parseInt(event.target.getAttribute("sort")) ? 0 : 1;
    event.target.setAttribute("sort",sort);
    if(event.target.parentElement.getElementsByTagName("i").length > 0){
      for(let ii of event.target.parentElement.getElementsByTagName("i"))
        ii.remove();
    }
    
    if(sort){
      event.target.innerHTML += '<i class="far fa-angle-double-up" style="color:#749047"></i>';

    }else{
      
      event.target.innerHTML += '<i class="far fa-angle-double-down" style="color:#749047"></i>';
    }
    switching = true;
    /*Make a loop that will continue until
    no switching has been done:*/
    while (switching) {
      //start by saying: no switching is done:
      switching = false;
      rows = table.rows;
      /*Loop through all table rows (except the
      first, which contains table headers):*/
      for (i = 1; i < (rows.length - 1); i++) {
        //start by saying there should be no switching:
        shouldSwitch = false;
        /*Get the two elements you want to compare,
        one from current row and one from the next:*/
        x = rows[i].getElementsByTagName("TD")[cellIndex];
        y = rows[i + 1].getElementsByTagName("TD")[cellIndex];
        //check if the two rows should switch place:
        if(!sort){
          if (parseInt(x.innerHTML.replace(/,/g, "").toLowerCase()) > parseInt(y.innerHTML.replace(/,/g, "").toLowerCase())) {
            //if so, mark as a switch and break the loop:
            shouldSwitch = true;
            break;
          }
        }else{
          if (parseInt(x.innerHTML.replace(/,/g, "").toLowerCase()) < parseInt(y.innerHTML.replace(/,/g, "").toLowerCase())) {
            //if so, mark as a switch and break the loop:
            shouldSwitch = true;
            break;
          }
        }
        
      }
      if (shouldSwitch) {
        /*If a switch has been marked, make the switch
        and mark that a switch has been done:*/
        rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
        switching = true;
      }
      
    }
    for(let i=1;i<rows.length;i++){
      rows[i].cells[0].innerText=i;
    }
  }
  getCombo(){
    let that = this;
    let ComboParam = this.state.ComboParam.pop();
    let param = {
      token: localStorage.getItem("api_token"),
      DBTableFieldLabel:ComboParam.DBTableFieldLabel,
      DBTableFieldValue:ComboParam.DBTableFieldValue,
      DbTableName:ComboParam.DbTableName
    };


    this.setState({
      loading: 1
    })

    let SCallBack = function (response) {
      let x=[];
      for(let i=0;i<response.data.result.length;i++){
        x.push({DBTableFieldLabel:response.data.result[i][ComboParam.DBTableFieldLabel],DBTableFieldValue:response.data.result[i][ComboParam.DBTableFieldValue]});
      }
      for(let item of that.state.Filters){
        if(item.FId == ComboParam.FId){
          item.Combo = x
        }
      }
      that.setState({
        Filters:that.state.Filters,
        loading: 0
      })
      if(that.state.ComboParam.length > 0)
          that.getCombo();
      

    };
    let ECallBack = function (error) {
      Alert.error('عملیات انجام نشد', 5000);
      that.setState({
        loading: 0
      })
    }
    this.Server.send("ReportApi/GetCombo", param, SCallBack, ECallBack)
  }
  Clear(){
    this.setState({
      Filters:[]
    })
    this.GetFilters();
  }
  showReports() {
    let that = this;
    this.setState({
      output:''
    })
    debugger;
    let param = {
      token: localStorage.getItem("api_token"),
      number:this.state.number,
      SeveralShop:this.state.SeveralShop,
      mainShop:this.state.mainShop
    };
    for(let item of this.state.ShowParam){
      if(item.type == "5" && this.state[item.name]){
        param[item.name]=this.state[item.name].local("fa").format("jYYYY/jM/jD");

      }else if(item.type == "4"){
        param[item.name.split("_")[0]]=this.state[item.name+"_val"];
      }else{
        param[item.name]=this.state[item.name];
      }
    }


    this.setState({
      loading: 1
    })

    let SCallBack = function (response) {
      let Date = "<div style='display:flex'>";
      for(let i=0;i<that.state.Filters.length;i++){
        if(that.state.Filters[i].latinName == "fromDate" && that.state[that.state.Filters[i].latinName])
          Date+= "<div style='text-align:right;font-size:28px'> تاریخ : </div><div style='text-align:right;font-size:28px'><span style='text-align:right;font-size:28px'> از </span><span>"+that.state[that.state.Filters[i].latinName].local('fa').format('jYYYY/jM/jD')+"</span></div>"
        if(that.state.Filters[i].latinName == "UntilDate"  && that.state[that.state.Filters[i].latinName])
          Date+= "<div style='text-align:right;font-size:28px'><span style='text-align:right;font-size:28px'> تا </span><span>"+that.state[that.state.Filters[i].latinName].local('fa').format('jYYYY/jM/jD')+"</span></div>"

      }

      Date+="</div><br />";
      let printOutput= Date + response.data.result;
      that.setState({
        printOutput:printOutput,
        output:response.data.result,
        ExcelRep:response.data.ExcelRep,
        loading: 0
      })

      

    };
    let ECallBack = function (error) {
      Alert.error('عملیات انجام نشد', 5000);
      that.setState({
        loading: 0
      })
    }
    this.Server.send("ReportApi/"+this.state.method, param, SCallBack, ECallBack)
  }
  showReportsDetail(detailId) {
    let that = this;
   
    let param = {
      token: localStorage.getItem("api_token"),
      number:this.state.number,
      SeveralShop:this.state.SeveralShop,
      mainShop:this.state.mainShop
    };
    for(let item of this.state.ShowParam){
      if(item.type == "5" && this.state[item.name]){
        param[item.name]=this.state[item.name].local("fa").format("jYYYY/jM/jD");

      }else if(item.type == "4"){
        param[item.name.split("_")[0]]=this.state[item.name+"_val"];
      }else{
        param[item.name]=this.state[item.name];
      }
    }
    param["detailId"]=detailId;


    this.setState({
      loading: 1
    })

    let SCallBack = function (response) {
      
      that.setState({
        outputDetail:response.data.result,
        VisibleDialog:true,
        loading: 0
      })
      

    };
    let ECallBack = function (error) {
      Alert.error('عملیات انجام نشد', 5000);
      that.setState({
        loading: 0
      })
    }
    this.Server.send("ReportApi/"+this.state.method+"_detail", param, SCallBack, ECallBack)
  }
  getReportDetail(){
    let that = this;
    that.setState({
      loading: 1
    })
    let condition = {condition:{"number":this.props.number.toString()}}
    that.Server.send("AdminApi/GetReports", condition, function (response) {
      that.setState({
        loading: 0,
        reportName:response.data.result[0] ? response.data.result[0].name : "",
        legend:response.data.result[0] ? (" " + response.data.result[0].name + "(" + that.props.number + ")") : ""
      })
      that.GetFilters();


    }, function (error) {

      that.setState({
        loading: 0
      })

    })
  }
  getSettings(){

    let that = this;
    that.setState({
      loading: 1
    })
    that.Server.send("AdminApi/getSettings", {}, function (response) {
      that.setState({
        loading: 0
      })
      if (response.data.result) {
        that.setState({
          SeveralShop: response.data.result[0].SeveralShop,
          Disabled: response.data.result[0].Disabled || false
        })
      }
      that.getMainShopInfo();

    }, function (error) {
      that.getMainShopInfo();

      that.setState({
        loading: 0
      })

    })


  }
  componentDidMount() {
    socket.on("autoPrint", (data) => {
      this.handlePrint()
    });
    this.getSettings();
  }
  generateExcel(){
    if(!this.state.ExcelRep)
      return;
    let that = this;
    let param = {
      token: localStorage.getItem("api_token"),
      ExcelRep:this.state.ExcelRep
    };


    this.setState({
      loading: 1
    })

    let SCallBack = function (response) {
      that.setState({
        loading: 0

      })
      window.open(response.data.result)

      

    };
    let ECallBack = function (error) {
      Alert.error('عملیات انجام نشد', 5000);
      that.setState({
        loading: 0
      })
    }
    this.Server.send("ReportApi/generateExcel", param, SCallBack, ECallBack)

  }
  init(){
    let that = this;
    let param = {
      token: localStorage.getItem("api_token"),
    };
    this.setState({
      output:'',
      loading: 1
    })
    let SCallBack = function (response) {
      that.setState({
        loading: 0,
        ShopName_name: response.data.authData.shopId,
        mainShop: response.data.authData.shopId == that.state.MainShopInfo._id
      })
      that.getReportDetail();

    };
    let ECallBack = function (error) {
      that.setState({
        loading: 0
      })
      console.log(error)
    }
    this.Server.send("MainApi/checktoken", param, SCallBack, ECallBack)
  }
  getMainShopInfo(){
    let that = this;
    let param = {
        main: true
    };
    
    let SCallBack = function (response) {
        that.setState({
            MainShopInfo:response.data.result[0]||{}
        })
        that.init();
    };

    let ECallBack = function (error) {
        that.init();


    }
    that.Server.send("AdminApi/ShopInformation", param, SCallBack, ECallBack)
}
onSelect(event) {
  let latinName = this.state.AutoCompleteParam[this.state.AutoCompleteIndex].latinName;
  this.setState({[latinName]:event.value.name,[latinName+"_val"]:event.value._id})
}


suggestBrands(event) {
    let f = this.state.AutoCompleteParam[this.state.AutoCompleteIndex];
    let that = this;
    this.setState({ brand: event.query, Count: 0 });
    let param = {
      title: event.query,
      table:f.DbTableName,
      name:f.latinName.split("_")[1]
    };
    let SCallBack = function (response) {
      let brandSuggestions = [];
      response.data.result.reverse().map(function (v, i) {
        brandSuggestions.push({ _id: v[f.DBTableFieldValue],name:v[f.DBTableFieldLabel]})
      })
      that.setState({ brandSuggestions: brandSuggestions });
    };

    let ECallBack = function (error) {

    }
    that.Server.send("ReportApi/searchItems", param, SCallBack, ECallBack)


}
itemTemplate(brand) {
    return (
      <div className="p-clearfix" style={{ direction: 'rtl',maxWidth:'100%' }} >
        <div style={{ margin: '10px 10px 0 0' }} className="row" _id={brand._id} >
          <div className="col-8" _id={brand._id} style={{ textAlign: 'right' }}>
            <span className="iranyekanwebregular" style={{ textAlign: 'right', overflow: 'hidden' }} _id={brand._id} >
              <span style={{whiteSpace:'pre-wrap'}} _id={brand._id}>{brand.name}</span><br />
            </span>
          </div>
          
        </div>
      </div>
    );
  }
  componentWillReceiveProps(nextProps) {
        this.init();
  }
  render() {

    return (
      !this.state.Disabled ?
        <div style={{ direction: 'rtl' }}>
        {this.state.loading == 1 &&
          <div style={{ position: 'fixed', zIndex: 2000, top: 10, left: 15, backgroundColor: '#e89f31', padding: '2px 20px' }}>
            <Loader content="لطفا صبر کنید ..." className="yekan" />
          </div>
        }
        <div className="row justify-content-center mt-5">
              <div className="row">
                    <div className="col-12" style={{ display: "none" }}>
                      <ComponentToPrint SeveralShop={this.state.SeveralShop} htmlParam={this.state.printOutput} forUser="1" ref={el => (this.componentRef = el)} />
                    </div>
                  </div>
          <div className="col-12" style={{ background: '#fff' }}>

          <Fieldset legend={this.state.legend} toggleable collapsed={this.state.panelCollapsed} onToggle={(e) => this.setState({panelCollapsed: e.value})}>
          <div className="row" style={{alignItems:'baseline'}}>
              {this.state.Filters && this.state.Filters.map((item, index)=>{

                if(item.type=="1"){
                  return(
                    
                    <div className="col-12 col-lg-3">
                      <div className="group" >
                          <input className="form-control YekanBakhFaBold"  style={{textAlign:'center'}} type="text" id={item.latinName} name={item.latinName} value={this.state[item.latinName]}  onChange={(event)=>{this.setState({[item.latinName]:event.target.value})}}   required  />
                          <label className="YekanBakhFaBold">{item.name}</label>
                      </div>
                    </div>
                  )
                }
                if(item.type=="2"){
                  return(
                    <div className="col-12 col-lg-3">
                      <div style={{display:'flex'}} >
                      <Checkbox inputId={item.latinName} value={item.latinName} checked={this.state[item.latinName]} onChange={(event)=>{this.setState({[item.latinName]:event.checked})}} ></Checkbox>

                      <label htmlFor={item.latinName} className="p-checkbox-label yekan" style={{ paddingRight: 5 }}>{item.name}</label>
                      </div>
                    </div>
                  )
                }
                if(item.type=="3"){
                  if(item.DbTableName =="shops" &&  !this.state.mainShop){
                    
                    return(
                      <div className="col-12 col-lg-3" style={{display:'none'}}>
                        <div className="group" >
                            <input className="form-control YekanBakhFaBold"  style={{textAlign:'center'}} type="hidden" id={item.latinName} name={item.latinName} value={this.state[item.latinName]}  onChange={(event)=>{this.setState({[item.latinName]:event.target.value})}}   required  />
                            <label className="YekanBakhFaBold">{item.name}</label>
                        </div>
                      </div>
                    )

                  }else{
                    return(
                      <div className="col-12 col-lg-3" style={{textAlign:'right',marginBottom:20,marginTop:20,direction:'ltr'}}>
                        <Dropdown showClear  filter id={item.latinName} name={item.latinName} placeholder={item.name} value={this.state[item.latinName]} optionLabel="DBTableFieldLabel" style={{ width: '100%' }} optionValue="DBTableFieldValue" options={item.Combo} onChange={(event)=>{
                          this.setState({[item.latinName]:event.target.value})}
                          
                          } />
                        
                       
                      </div>
                    )
                    

                  }
                     
                }
                if(item.type=="4"){
                  return(
                    <div className="col-12 col-lg-3">
                      <div className="group" >
                      <AutoComplete placeholder={item.name}  style={{ width: '100%' }} onChange={(event)=>{this.setState({[item.latinName]:event.value,AutoCompleteIndex:item.index,[item.latinName+"_val"]:''})}} itemTemplate={this.itemTemplate.bind(this)} value={this.state[item.latinName]} onSelect={(e) => this.onSelect(e)} suggestions={this.state.brandSuggestions} completeMethod={this.suggestBrands.bind(this)} />

                      </div>
                    </div>
                  )
                }
                if(item.type=="5"){
                  return(
                    <div className="col-12 col-lg-3">
                      <DatePicker
                        onChange={value =>{this.setState({[item.latinName]:value})}}
                        value={this.state[item.latinName]}
                        isGregorian={false}
                        timePicker={false}
                        placeholder={item.name}
                        persianDigits={false}

                      />
                    </div>
                  )
                }
                
              })}
              
            </div>
            <div className="row" style={{marginTop:50}}>
                <button className="btn btn-primary irsans" onClick={this.showReports} style={{ width: "200px", marginTop: "5px", marginBottom: "5px",marginLeft:10 }}> مشاهده گزارش </button>
             

              
              <button className="btn btn-secondary irsans" onClick={this.Clear} style={{ width: "200px", marginTop: "5px", marginBottom: "5px",marginLeft:10 }}>شروع مجدد </button>
              {this.state.output != '' && this.state.ExcelRep &&
                <button className="btn btn-success irsans" onClick={this.generateExcel} style={{ width: "200px", marginTop: "5px", marginBottom: "5px",marginLeft:10,marginRight:10 }}> ساخت خروجی اکسل </button>
              }
              {this.state.output != '' &&
              <ReactToPrint
                        content={() => this.componentRef}
                      >
                        <PrintContextConsumer>
                          {({ handlePrint }) => (
                            

                            <Button label="چاپ گزارش"  onClick={() => {

                              setTimeout(function () {  
                                handlePrint();

                              }, 0)
                            }} style={{ cursor: 'pointer',marginTop: "5px", marginBottom: "5px" }} aria-hidden="true"></Button>
                          )}
                        </PrintContextConsumer>
                      </ReactToPrint>
              }
            </div>
            </Fieldset>
            <div onClick={(e) => {this.sortTable(e)}}>

            <div className="report-container" onClick={(event)=>{
              if(event.target.closest("TR") && event.target.closest("TR").getAttribute("_id")){
                this.showReportsDetail(event.target.closest("TR").getAttribute("_id"))

              }
            }}  dangerouslySetInnerHTML={{ __html: this.state.output}} > 

            </div>
            </div>
            
          </div>

        </div>
        <Dialog visible={this.state.VisibleDialog} onHide={()=>{this.setState({VisibleDialog:false})}} style={{ width: '60vw' }} maximizable={true} maximized={false}>
          <div className="report-container" dangerouslySetInnerHTML={{ __html: this.state.outputDetail}} > 
          </div>
        </Dialog>

      </div>
      :
      <div style={{display:'flex',justifyContent:'center',alignItems:'center',flexDirection:'column',height:300}}>
        <h3 style={{color:'red'}}>دسترسی به این بخش از سامانه غیر فعال شده است . برای اطلاع از جزئیات با مسئول فنی تماس بگیرید ...</h3>
      </div>
      
      
      
    )
  }
}
const mapStateToProps = (state) => {
  return {
    username: state.username
  }
}
export default withRouter(
  connect(mapStateToProps)(Show_Reports)
);