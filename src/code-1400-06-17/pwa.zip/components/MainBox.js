import React, { Component } from 'react';
import axios from 'axios'
import { BrowserRouter, Route, withRouter, Redirect, Link } from 'react-router-dom'
import { ProgressSpinner } from 'primereact/progressspinner';


import Swiper from 'react-id-swiper';
import 'swiper/css/swiper.css';
import CatList from './CatList.js'

import Header from './Header.js'
import Header1 from './Header1.js'

import CartBox from './CartBox.js'



import Server from './Server.js'
import { connect } from 'react-redux';

const params5 = {
  autoplay: {
    delay: 5000,
    disableOnInteraction: false
  },
  loop: 1,
  centeredSlides: true,
  slidesPerView: 'auto',
  coverflowEffect: {
    rotate: 50,
    stretch: 0,
    depth: 100,
    modifier: 1,
    slideShadows: true
  },
  pagination: {
    el: '.swiper-pagination'
  }
}

class MainBox extends React.Component {
  constructor(props) {
    super(props);
    this.Server = new Server();
    let food = localStorage.getItem("food") || (this.props.location.search && this.props.location.search.split("food=")[1]);
    let aniaShop = (this.props.location.search && this.props.location.search.split("aniashop=")[1]);

    if(aniaShop)
      localStorage.removeItem("food");
    else
      localStorage.setItem("food",food);
    
    this.myRef = React.createRef()   // Create a ref object 
    this.state = {
      products: [],
      productsBestOff: [],
      BestShops: [],
      ShowLoading:true,

      catsList:[],
      shopList:[],
      cats: [],
      absoluteUrl: this.Server.getAbsoluteUrl(),
      url: this.Server.getUrl()
    }
    this.SendToCart = this.SendToCart.bind(this);

  }
  getUser(){
    let that = this;
    if(!that.props.mobile)
      return;
    that.Server.send("MainApi/getuser", {username:that.props.mobile,noPass:1}, function (response) {
      if(response.data.error){
        that.Server.send("MainApi/autoRegister", {username:that.props.mobile,password:that.props.password,address:'',name:that.props.fullname,RaymandUser:that.state.username}, function (response) {
        }, function (error) {
          localStorage.setItem("api_token",response.data.token);

        })
      }else{
        localStorage.setItem("api_token",response.data.token);


      }
      that.setState({
        api_token : response.data.token
      })
      
    }, function (error) {
    })
  }
  getSettings(){
    axios.post(this.state.url+'getSettings', {
        token: localStorage.getItem("api_token")
      })
      .then(response => {
        this.setState({
            Template:response.data.result ? response.data.result.Template : "1",
            ProductBase: response.data.result ? response.data.result.ProductBase : false,
            SaleFromMultiShops: response.data.result ? response.data.result.SaleFromMultiShops : false
        })
        this.getCategory();

      })
      .catch(error => {
        console.log(error)
        this.getCategory();

      })
  }
  persianNumber(input) {
    var persian = { 0: '۰', 1: '۱', 2: '۲', 3: '۳', 4: '۴', 5: '۵', 6: '۶', 7: '۷', 8: '۸', 9: '۹' };
    var string = (input + '').split('');
    var count = string.length;
    var num;
    for (var i = 0; i <= count; i++) {
      num = string[i];
      if (persian[num]) {
        string[i] = persian[num];
      }
    }
    return string.join('');
  }
  getCategory() {
    let condition = { condition: { showInSite: true } };
    axios.post(this.state.url + 'GetCategory', condition)
      .then(response => {
        let resp = [];
        let forRem = []
        response.data.result.sort((a, b) => (a.order > b.order) ? 1 : ((b.order > a.order) ? -1 : 0));
        
          this.setState({
            catsList: response.data.result
          })
          if(!this.state.ProductBase){
          
            this.getShops();
          }else{
            this.getPics();

          }


      })
      .catch(error => {
       
        console.log(error)
      })

  }
  getShops(){
      let condition = {condition:{showInSite:true}};
      axios.post(this.state.url + 'getShops', condition)
        .then(response => {

            this.setState({
              shopList: response.data.result
            })
            if(!this.state.ProductBase)
               this.getPics();

  
  
        })
        .catch(error => {

        })
  
  }
  getPics(l, type) {
    let that = this;
    
    axios.post(this.state.url + 'getPics', {})
      .then(response => {
        response.data.result.map(function (item, index) {
          if (item.name == "file1"){
            that.setState({
              logo1: that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1],
              link1: item.link,
              text1: item.text
            })
          }
           
          if (item.name == "file2")
            that.setState({
              logo2: that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1],
              link2: item.link,
              text2: item.text
            })
          if (item.name == "file3")
            that.setState({
              logo3: that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1],
              link3: item.link,
              text3: item.text
            })
          if (item.name == "file4")
            that.setState({
              logo4: item.fileUploaded ? that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1] : null,
              link4: item.link,
              text4: item.text
            })
            
          if (item.name == "file5")
            that.setState({
              logo5: item.fileUploaded ? that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1]:null,
              link5: item.link,
              text5: item.text
            })
          if (item.name == "file6")
              that.setState({
                logo6: item.fileUploaded ? that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1]:null,
                link6: item.link,
                text6: item.text
              })
          if (item.name == "file7")
              that.setState({
                logo7: item.fileUploaded ? that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1]:null,
                link7: item.link,
                text7: item.text
              })
          if (item.name == "file8")
            that.setState({
              logo8: item.fileUploaded ? that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1]:null,
              link8: item.link,
              text8: item.text
            })
          if (item.name == "file9")
            that.setState({
              logo9: item.fileUploaded ? that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1]:null,
              link9: item.link,
              text9: item.text
            })  
          if (item.name == "file11"){
            that.setState({
              SpecialImage: that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1]
            })
          }
          if (item.name == "file13"){

            that.setState({
              loading_pic: that.state.absoluteUrl +  item?.fileUploaded?.split("public")[1]
            })
          }
              
        })
        setTimeout(()=>{
          that.setState({
            ShowLoading:false
          })
        },3000)
        this.getProducts(8, "special");

        
        
      })
      .catch(error => {
      })

  }
  roundPrice(price) {
    return price.toString();
    if (price == 0)
      return price;
    price = parseInt(price).toString();
    let C = "500";
    let S = 3;
    if (price.length <= 5) {
      C = "100";
      S = 2;
    }
    if (price.length <= 4) {
      C = "100";
      S = 2;
    }
    let A = price.substr(price.length - S, S)
    if (A == C || A == "000" || A == "00")
      return price;
    if (parseInt(A) > parseInt(C)) {
      let B = parseInt(A) - parseInt(C);
      return (parseInt(price) - B + parseInt(C)).toString();
    } else {
      let B = parseInt(C) - parseInt(A);
      return (parseInt(price) + B).toString();
    }


  }
  getProducts(l, type) {
    axios.post(this.state.url + 'getProducts', {
      token: localStorage.getItem("api_token"),
      levelOfUser: this.state.levelOfUser,
      type: type,
      limit: l
    })
      .then(response => {
        if (type == "special") {
          debugger;
          this.setState({
            products: response.data.result
          })

        }
      })
      .catch(error => {
        console.log(error)
      })

  }

  SendToCart(PId, Number, UId, Price) {
    let that = this;

    axios.post(this.state.url + 'checktoken', {
      token: localStorage.getItem("api_token")
    })
      .then(response => {
        that.setState({
          UId: response.data.authData.userId
        })
        let param = {
          PId: PId,
          Number: Number,
          UId: response.data.authData.userId,
          Price: Price,
          Status: "0",
          Type: "insert",
          token: localStorage.getItem("api_token")
        };
        let SCallBack = function (response) {
          let res = response.data.result;
          //alert(res)
          /*let { history } = that.props;
          history.push({
              pathname: '/cart'
          })*/
          that.setState({
            GotoCart: true
          })

        };
        let ECallBack = function (error) {
          //alert(error)
        }
        that.Server.send("MainApi/ManageCart", param, SCallBack, ECallBack)

      })
      .catch(error => {
        that.setState({
          GotoLogin: true
        })
        console.log(error)
      })

  }
  componentDidMount() {

    this.getSettings();

  }
  GoToProduct(item){
		if(!this.props.ProductBase && item.product_detail && item.product_detail.length > 1){
			this.setState({
				productsDetailArray:item.product_detail,
				productsDetailArrayRef:item,
				VisibleDialog:true
			})
			
		}else{
			let url = this.props.ProductBase ? 'Products?id='+((item.product_detail && item.product_detail.length > 0) ? item.product_detail[0]._id : item._id)+'' : 'Shop?id='+((item.Seller && item.Seller.length > 0) ? item.Seller[0]._id : '')+'&cat='+item.category_id+'';

			//this.GoToShop(url)
		}
		
	}
  GoToShop(url){
		
    this.setState({
      ShopLink:url
    })
  
  }
  render() {
    
		if (this.state.id) {
			return <Redirect to={"/products?id=" + this.state.id} push={true} />;
		}
		if (this.state.ShopLink) {
			return <Redirect to={this.state.ShopLink} push={true} />;
		}
    if (this.state.GotoLogin) {
      return <Redirect to={"/login"} push={true} />;
    }
    if (this.state.GotoCart) {
      return <Redirect to={"/cart"} push={true} />;
    }
    return (

      <div style={{height:'100%'}}>
        {!this.state.ShowLoading ?
        <div className="row">
           <Header credit={this.state.credit} small="1"  />
           <div style={{padding:10}}>
           <Header1 />

             </div>
           <div style={{textAlign:'center',display:'flex',justifyContent:'center'}} >

            <div style={{width:'95%'}}>
              <Swiper {...params5} >
                    <div>
                      {this.state.link1 && this.state.link1.indexOf("http") > -1 ?
                        <Link to={this.state.link1}  style={{ textDecoration: 'none' }}>
                          {this.state.text1 &&
                            <p className="iranyekanweblight  p-md-3 d-md-block d-none animate__animated animate__fadeInLeftBig " style={{ overflow: 'hidden', height: 300, maxHeight: 300, borderRadius: 5, position: 'absolute', zIndex: 2, fontSize: 18, color: 'rgb(255, 255, 255)', backgroundColor: 'rgb(27 26 25 / 58%)', width: 350, textAlign: 'center', boxShadow: 'rgb(62 36 36) 10px 10px 15px', top: 30, left: 50 }}>{this.state.text1}</p>
                          }
                          <img src={this.state.logo1} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }} title={this.state.text1} />
                        </Link>
                        :
                        <Link to={`${process.env.PUBLIC_URL}/` + this.state.link1}  href="#" style={{ textDecoration: 'none' }}>
                          {this.state.text1 &&
                            <p className="iranyekanweblight  p-md-3 d-md-block d-none animate__animated animate__fadeInLeftBig " style={{ overflow: 'hidden', height: 300, maxHeight: 300, borderRadius: 5, position: 'absolute', zIndex: 2, fontSize: 18, color: 'rgb(255, 255, 255)', backgroundColor: 'rgb(27 26 25 / 58%)', width: 350, textAlign: 'center', boxShadow: 'rgb(62 36 36) 10px 10px 15px', top: 30, left: 50 }}>{this.state.text1}</p>
                          }
                          <img src={this.state.logo1} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }} title={this.state.text1} />
                        </Link>
                      }
                    </div>

                    <div>
                      {this.state.link2 && this.state.link2.indexOf("http") > -1 ?
                        <Link to={this.state.link2} className=""  style={{ textDecoration: 'none' }}>
                          {this.state.text2 &&
                            <p className="iranyekanweblight  p-md-3 d-md-block d-none " style={{ overflow: 'hidden', height: 300, maxHeight: 300, borderRadius: 5, position: 'absolute', zIndex: 2, fontSize: 18, color: 'rgb(255, 255, 255)', backgroundColor: 'rgb(27 26 25 / 58%)', width: 350, textAlign: 'center', boxShadow: 'rgb(62 36 36) 10px 10px 15px', top: 30, left: 50 }}>{this.state.text2}</p>
                          }
                          <img src={this.state.logo2} style={{borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:160,width:'100%' }} title={this.state.text2} />

                        </Link>
                        :
                        <Link to={`${process.env.PUBLIC_URL}/` + this.state.link2} className=""  href="#" style={{ textDecoration: 'none' }}>
                          {this.state.text2 &&
                            <p className="iranyekanweblight  p-md-3 d-md-block d-none " style={{ overflow: 'hidden', height: 300, maxHeight: 300, borderRadius: 5, position: 'absolute', zIndex: 2, fontSize: 18, color: 'rgb(255, 255, 255)', backgroundColor: 'rgb(27 26 25 / 58%)', width: 350, textAlign: 'center', boxShadow: 'rgb(62 36 36) 10px 10px 15px', top: 30, left: 50 }}>{this.state.text2}</p>
                          }
                          <img src={this.state.logo2} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }} title={this.state.text2} />

                        </Link>
                      }
                    </div>

                    <div>
                      {this.state.link3 && this.state.link3.indexOf("http") > -1 ?
                        <Link to={this.state.link3} className=""  style={{ textDecoration: 'none' }}>
                          {this.state.text3 &&
                            <p className="iranyekanweblight  p-md-3 d-md-block d-none " style={{ overflow: 'hidden', height: 300, maxHeight: 300, borderRadius: 5, position: 'absolute', zIndex: 2, fontSize: 18, color: 'rgb(255, 255, 255)', backgroundColor: 'rgb(27 26 25 / 58%)', width: 350, textAlign: 'center', boxShadow: 'rgb(62 36 36) 10px 10px 15px', top: 30, left: 50 }}>{this.state.text3}</p>
                          }
                          <img src={this.state.logo3} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }} title={this.state.text3} />
                        </Link>
                        :
                        <Link to={`${process.env.PUBLIC_URL}/` + this.state.link3} className=""  href="#" style={{ textDecoration: 'none' }}>
                          {this.state.text3 &&
                            <p className="iranyekanweblight  p-md-3 d-md-block d-none " style={{ overflow: 'hidden', height: 300, maxHeight: 300, borderRadius: 5, position: 'absolute', zIndex: 2, fontSize: 18, color: 'rgb(255, 255, 255)', backgroundColor: 'rgb(27 26 25 / 58%)', width: 350, textAlign: 'center', boxShadow: 'rgb(62 36 36) 10px 10px 15px', top: 30, left: 50 }}>{this.state.text3}</p>
                          }
                          <img src={this.state.logo3} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }} title={this.state.text3} />
                        </Link>
                      }
                    </div>
                  </Swiper>
                  </div>
          </div>
            <div style={{display:'flex',justifyContent:'space-around',padding:10}} >
              <div className="col-6" style={{marginTop:5,marginBottom:5,textAlign:'center'}}>
                  <Link to={`${process.env.PUBLIC_URL}/` + this.state.link4} href="#"  style={{ textDecoration: 'none' }}>
                      <img style={{ width: '95%',borderRadius:10 }} src={this.state.logo4}></img>
                  </Link>
              </div>
              <div className="col-6" style={{marginTop:5,marginBottom:5,textAlign:'center'}}>
                  <Link to={`${process.env.PUBLIC_URL}/` + this.state.link5} href="#"  style={{ textDecoration: 'none' }}>
                    <img style={{ width: '95%',borderRadius:10 }} src={this.state.logo5}></img>
                  </Link>
              </div>
              </div>            
            
          <div style={{display:'flex',overflow:'auto',flexDirection:'row-reverse'}} className="bg">
            <img src={this.state.SpecialImage} style={{width:160}} />
          {this.state.products && this.state.products.map((item,index)=>{
            					var img = item.fileUploaded ? this.state.absoluteUrl + item.fileUploaded.split("public")[1] : '';

                      return(
                        <Link className="car-details" to={`${process.env.PUBLIC_URL}/Products?name=${item.title}&id=` + ((item.product_detail && item.product_detail.length > 0) ? item.product_detail[0]._id : item._id)}  style={{ background:'#fff',display: 'block', textDecorationStyle: 'none', color: '#333', border: "1px solid rgb(239 239 239)", margin: 5, padding: 5, borderRadius: 5 }} >
												<div className="p-grid p-nogutter" style={{position:'relative'}} >
													<div className="p-col-12 c-product-box__img" align="center" >
														<img src={img} style={{borderRadius:4,width:100}} alt="" />
													</div>
													<div className="p-col-12 car-data" style={{ marginTop: 10 }}>
														<div className="car-title iranyekanwebmedium block-ellipsis" style={{ textAlign: 'center' }}>{item.title}</div>

														{
															item.number > 0
																?
																<div>
																	{(this.state.UId || !item.ShowPriceAftLogin) &&
																		<div>
																			{
																				((!item.NoOff ? parseInt(this.props.off||0) : 0) + item.off) > "0" ?
																					<div className="car-subtitle iranyekanweblight" style={{ marginTop:15,textAlign: 'center', textDecoration: 'line-through', fontSize: 11, color: '#a09696' }} >{this.persianNumber(this.roundPrice(item.price.toString()).replace(/\B(?=(\d{3})+(?!\d))/g, ","))} </div>
																					:
																					<div className="car-subtitle iranyekanweblight" style={{ textAlign: 'center', textDecoration: 'line-through', fontSize: 11, color: '#a09696', height: 16 }} ></div>
																			}
																			<div className="car-subtitle iranyekanweblight" style={{ textAlign: 'center',marginTop:15 }} ><span className="iranyekanweblight" style={{ float: 'left', fontSize: 11, marginTop: 10 }}>تومان</span> <span className="iranyekanweblight" style={{ fontSize: 20 }}>{this.persianNumber(this.roundPrice((item.price - ((item.price * (item.off + (!item.NoOff ? parseInt(this.props.off||0) : 0))) / 100)).toString()).replace(/\B(?=(\d{3})+(?!\d))/g, ","))}</span> </div>
																		</div>
																	}
																</div>
																:
																(this.state.UId || !item.ShowPriceAftLogin) &&
																<div>

																	<div className="car-subtitle iranyekanweblight" style={{ height: 22 }} ></div>
																	<div className="car-subtitle iranyekanweblight" style={{ textAlign: 'center' }} ><span className="iranyekanweblight" style={{ fontSize: 14, marginTop: 10, color: 'red' }}>ناموجود</span> </div>
																</div>
														}

													</div>
													{
														item.number > 0 && ((!item.NoOff ? parseInt(this.props.off||0) : 0) + item.off) > "0" &&
														<div className="car-title iranyekanweblight off" style={{ position: 'absolute', top: 0 }} >{this.persianNumber(((!item.NoOff ? parseInt(this.props.off||0) : 0) + item.off))} %</div>

													}

												</div>
											</Link>
                      )
                  })
                  }
            </div>
            
          <div className="col-12" >
            {
              this.state.catsList[0] &&
              <CatList _id={this.state.catsList[0]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[0].name} name={this.state.catsList[0].name} />

            }
            </div>
            <div className="col-12" >
            {
              this.state.catsList[1] &&
              <CatList _id={this.state.catsList[1]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[1].name} name={this.state.catsList[1].name} />

            }
            </div>
            
            <div className="col-12" style={{marginTop:5,marginBottom:5,textAlign:'center'}}>
            <Link to={`${process.env.PUBLIC_URL}/` + this.state.link8} href="#"  style={{ textDecoration: 'none', height: 120 }}>
                        <img style={{ width: '90%',borderRadius:10 }} src={this.state.logo8}></img>
                      </Link>
               
           
             </div>
          
            <div className="col-12" >
            {
              this.state.catsList[2] &&
              <CatList _id={this.state.catsList[2]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[2].name} name={this.state.catsList[2].name} />

            }
            </div>
            
            
            <div className="col-12" >
            {
              this.state.catsList[3] &&
              <CatList _id={this.state.catsList[3]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[3].name} name={this.state.catsList[3].name} />

            }
            </div>

            <div className="col-12" style={{marginTop:5,marginBottom:5,textAlign:'center'}}>

            <Link to={`${process.env.PUBLIC_URL}/` + this.state.logo9} href="#"  style={{ textDecoration: 'none', height: 120 }}>
                        <img style={{ width: '90%',borderRadius:10 }} src={this.state.logo9}></img>
                      </Link>
           
              </div>
           
            <div className="col-12" >
            {
              this.state.catsList[4] &&
              <CatList _id={this.state.catsList[4]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[4].name} name={this.state.catsList[4].name} />

            }
            </div>
            <div className="col-12" >
            {
              this.state.catsList[5] &&
              <CatList _id={this.state.catsList[5]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[5].name} name={this.state.catsList[5].name} />

            }
            </div>
            
              <div className="col-12" style={{marginTop:5,marginBottom:5,textAlign:'center'}}>

            <Link to={`${process.env.PUBLIC_URL}/` + this.state.logo6} href="#"  style={{ textDecoration: 'none', height: 120 }}>
                        <img style={{ width: '90%',borderRadius:10 }} src={this.state.logo6}></img>
                      </Link>
           
              </div>
            <div className="col-12" >
            {
              this.state.catsList[6] &&
              <CatList _id={this.state.catsList[6]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[6].name} name={this.state.catsList[6].name} />

            }
            </div>
            
            <div className="col-12" style={{marginTop:5,marginBottom:5,textAlign:'center'}}>

            <Link to={`${process.env.PUBLIC_URL}/` + this.state.logo7} href="#"  style={{ textDecoration: 'none', height: 120 }}>
                        <img style={{ width: '90%',borderRadius:10 }} src={this.state.logo7}></img>
                      </Link>
           
              </div>

            <div className="col-12" >
            {
              this.state.catsList[7] &&
              <CatList _id={this.state.catsList[7]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[7].name} name={this.state.catsList[7].name} />

            }
            </div>
            <div className="col-12" >
            {
              this.state.catsList[8] &&
              <CatList _id={this.state.catsList[8]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[8].name} name={this.state.catsList[8].name} />

            }
            </div>
            <div className="col-12" >
            {
              this.state.catsList[9] &&
              <CatList _id={this.state.catsList[9]._id} UId={this.state.UId} ProductBase={this.state.ProductBase}  title={this.state.catsList[9].name} name={this.state.catsList[9].name} />

            }
            </div>
            

         <div style={{height:50}} />
         {this.state.api_token &&
            <CartBox />    
         }
        </div>
        :
        <div style={{ zIndex: 10000, height: '100%' }} >
                            <p style={{ textAlign: 'center', height: '100%', background: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>

                                <img src={this.state.loading_pic} style={{ width: '100%' }} />
                            </p>

                        </div>
    }

    </div>


    )
  }
}
function mapStateToProps(state) {        
	return {
	  username : state.username,
	  password : state.password,
	  ip : state.ip,
	  account:state.account,
	  place:state.place,
	  fullname : state.fullname,
	  mobile : state.mobile,
    LoginAnia:state.LoginAnia
	}
}
export default withRouter(
  connect(mapStateToProps)(MainBox)
);
