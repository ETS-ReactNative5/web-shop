import React, { Component } from 'react';
import axios from 'axios'
import { connect } from 'react-redux';
import Server from '../Server.js'
import Hesab from './Hesab.js'
import Vam from './Vam.js'
import Header from '../Header.js'
import { SelectButton } from 'primereact/selectbutton';
import { Tree } from 'primereact/tree';


import { withRouter, Route, Link, Redirect } from 'react-router-dom'
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Toast } from 'primereact/toast';
import Swiper from 'react-id-swiper';
import 'swiper/css/swiper.css';
import { ProgressSpinner } from 'primereact/progressspinner';
import './Home.css'

class Shop_List extends React.Component {
  constructor(props) {
    super(props);
    this.myRef = React.createRef()   // Create a ref object
    this.Server = new Server();
    localStorage.removeItem("food");
    this.state = {
      list:[],
      activePage: 1,
      CurrentTab: 1,
      groups:[],
      credit: 0,
      absoluteUrl: this.Server.getAbsoluteUrl(),
      url: this.Server.getUrl()

    }


  }
  componentDidMount() {
    this.getGroups();
  }
  getGroups(){
    let that = this;
    
    this.setState({
      ShowLoading: true
    })
    let SCallBack = function (response) {
        debugger;
      let list=[];  
      let listOptions=[];
      listOptions.push({name:'همه',value:''})
      let resp=null;
      let children=[];
      let filteredList = [{
        shops:[]
      }];

      let expandedKeys = [];
      debugger;
      for(let i=0;i<response.data.result.length;i++){
        children=[];
        let key=i.toString();
        expandedKeys.push({key:true})
        resp=response.data.result[i]; 
        listOptions.push({name:resp.name,value:resp._id})
        for(let shop of resp.shops){
          filteredList[0].shops.push(shop)
        }
        
      }  

      that.setState({
        listOptions:listOptions,
        listOption:listOptions[0].value,
        list:response.data.result,
        filteredList:filteredList,
        groups: response.data.result,
        ShowLoading: false
      })
    };
    let ECallBack = function (error) {
      
      that.setState({
        HasError:"رمز عبور اشتباه است"
      })
      console.log(error)
    }
    this.Server.send("AdminApi/getShopGroup", {getShops:1}, SCallBack, ECallBack)
  }

  render() {
    
    return (

      <div style={{ height: '100%' }}>

          <h2 className="iranyekanwebmedium" style={{textAlign:'center',color:'orange'}}>فروشگاههای طرف قرارداد مهرکارت</h2>
        {!this.state.ShowLoading ?
        <div  style={{height:'100%',direction:'rtl',textAlign:'center'}}>
            <SelectButton optionLabel="name" optionValue="value" style={{ marginBottom:30,marginTop:30,padding:10,textAlign: 'right',display:'flex',border:0,flexWrap:'nowrap',overflow:'auto' }} value={this.state.listOption} options={this.state.listOptions} onChange={(e) => {
                                            let filteredList = this.state.list.filter(function (value, index, array) {
                                              return (value._id == e.value);
                                            });
                                            if(!e.value){
                                                let shops=[];
                                                for(let i=0;i<this.state.list.length;i++){
                                                  for(let shop of this.state.list[i].shops){
                                                    shops.push(shop)
                                                  }
                                                }
                                                filteredList =[{
                                                  shops:shops
                                                }];
                                            }
                                            this.setState({ listOption: e.value||'',filteredList:filteredList });


                                        }}
            ></SelectButton>
            {this.state.filteredList && this.state.filteredList[0] && this.state.filteredList[0].shops.map((item,index)=>{
              let img = item.SpecialPic ? this.state.absoluteUrl + item.SpecialPic.split("public")[1] : 'https://sarvapps.ir/clipart1093188.png';
              let img2 = item.logo ? this.state.absoluteUrl + item.logo.split("public")[1] : '';

              return(

                <div style={{ position:'relative',marginBottom:50,padding:6,margin:6,background:'#eee',bottom:0,right:0}}>
                  <div style={{height:120,backgroundImage: `url(${img})`,backgroundSize:'cover',backgroundPosition:'center',backgroundRepeat:'no-repeat'}}>

                  </div>
                  {img2 &&
                    <div style={{position:'absolute',top:80,right:0,display:'none'}} >

                    <img src={img2}  />
                    </div>
                  }
                  <div style={{padding:10}}>
                  <div className="iranyekanwebmedium" style={{textAlign:'right',color:'orange',marginBottom:10}}>{item.name}</div>
                  <div className="iranyekanwebmedium" style={{textAlign:'right',fontSize:12,marginBottom:10}}>{item.about}</div>
                  <div className="iranyekanwebmedium" style={{textAlign:'right',fontSize:12,marginBottom:10}}>{item.address}</div>
                    </div>
                  

                </div>

              )
            })}

        </div>
        :
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center',height:'100%' }}>
          <ProgressSpinner style={{ paddingTop: 150 }} />
        </div>
      }
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    username: state.username,
    password: state.password,
    ip: state.ip,
    account: state.account,
    place: state.place,
    fullname: state.fullname,
    mobile: state.mobile
  }
}
export default connect(mapStateToProps)(Shop_List)

