import React from 'react';
import { connect } from "react-redux"
import Header from '../Header.js'
import { ProgressSpinner } from 'primereact/progressspinner';
import Form from '../Form.js'
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { Toast } from 'primereact/toast';
import { Checkbox } from 'primereact/checkbox';
import { Panel } from 'primereact/panel';

import { InputText } from 'primereact/inputtext';

import Server from '../Server.js'


class Support extends React.Component {

    constructor(props) {
        super(props);

        this.Server = new Server();
        this.SetReq = this.SetReq.bind(this);
        this.SetAnswer = this.SetAnswer.bind(this);

        this.toast = React.createRef();

        this.DelReq = this.DelReq.bind(this);
        this.EndReq = this.EndReq.bind(this);



        this.state = {
            ShowLoading: true,
            userData: {},
            scoreLog: [],
            scoreRows: [],
            score: -1,
            myReqs: [],
            AccountNumber: !this.props.shop ? this.props.location.search.split("account=")[1] : null,
            offRows: [],
            offRows_temp: [],
            absoluteUrl: this.Server.getAbsoluteUrl(),
            url: this.Server.getUrl(),
            url2: this.Server.getUrl(1)

        }

    }

    ConvertNumToFarsi(text) {
        var id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        if (!text)
            return text;
        return text.toString().replace(/[0-9]/g, function (w) {
            return id[+w]
        });
    }
    componentDidMount() {

        this.getuserInfo();
    }
    getUnit(All) {
        let that = this;
        let condition = All ? {} : { usersList: { $elemMatch: { "username": this.state.userData.username } } };
        this.Server.send("AdminApi/getUnitsList", { condition: condition }, function (response) {
            if (!All) {
                that.setState({
                    myUnit: response.data.result[0],
                    ShowLoading: false

                })
                that.GetReq();
            } else {
                let SendToArray = [];
                for (let i = 0; i < response.data.result.length; i++) {
                    SendToArray.push({ value: response.data.result[i].lTitle, desc: response.data.result[i].fTitle })
                }
                that.setState({
                    Units: response.data.result,
                    SendToArray: SendToArray,
                    ShowLoading: false

                })
                that.getUnit()

            }


        }, function (error) {
            that.setState({
                ShowLoading: false
            })
        })
        this.setState({
            ShowLoading: true
        })
    }
    getCode() {
        let that = this;
        let SCallBack = function (response) {
            let val = response.data.result[0].values;
            let SendToArray = that.state.SendToArray;
            /*if (val) {
                for (let i = 0; i < val.length; i++) {
                    SendToArray.push({ value: val[i].value, desc: val[i].desc })
                }
            }*/

            that.setState({
                SendToTitle:response.data.result[0].title,
                SendToArray: SendToArray,
                Priority:response.data.result[1].values[0].value,
                Subject:response.data.result[2].values[0].value,
                PriorityArray: response.data.result[1],
                SubjectArray: response.data.result[2],
                loading: 0
            })
        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
        }
        this.Server.send("AdminApi/GetCodes", { id: ["4", "5","14"] }, SCallBack, ECallBack)
    }
    getuserInfo() {
        let that = this;
        this.Server.send("MainApi/getUserData", { Key: "username", mobile: this.props.mobile }, function (response) {
            that.setState({
                userData: response.data.result[0]
            })
            that.getUnit(1);
        }, function (error) {
            that.setState({
                ShowLoading: false
            })
        })
        this.setState({
            getUserData: 0,
            ShowLoading: true
        })

    }
    getResponse() {

        this.getuserInfo();
    }
    GetReq(refresh,reqNumber,Unit) {
        let type = null;
        let that = this;
        let param = {
            token: localStorage.getItem("api_token"),
            username: this.state.userData.username,
            limit: 10,
            reqNumber: reqNumber,
            Unit:Unit,
            InShow: 1,
            InApp: 1,
            type: type,
            status:1
        };
        this.setState({
            ShowLoading: 1,
            visibleManageAction: false
        })
        let SCallBack = function (response) {
            let Ended=[],
                Current=[];
                debugger;
            if(!reqNumber){
                for(let i=0; i < response.data.result.length; i++){
                    let resp = response.data.result[i];
                    if((resp.request && resp.request[0] && resp.request[0].status == 1) || ((!resp.request ||!resp.request[0])  && resp.status == 1)){
                        Current.push(resp);
                    }else{
                        Ended.push(resp);
                    }
                }
            }else{
                Current =  response.data.result;
            }    
            
            that.setState({
                AllReq:response.data.result,
                myReqs: Current,
                Ended:Ended,
                ShowLoading: 0,
                ShowDialog: false,
                selectedReqId: null,
                selectedReqDetailId: null,
                selectedTitle: null,
                selectedDesc: null,
                changeSender:false
            })
            if (!refresh)
                that.getCode();

        };
        let ECallBack = function (error) {
            console.log(error)
            that.setState({
                ShowLoading: 0
            })
        }
        this.Server.send("CompanyApi/getRequest", param, SCallBack, ECallBack)
    }
    GetAnswer(item) {
        let that = this;
        debugger;
        this.setState({
            ShowLoading: 1,
            changeSender: false,
            desc: "",
            draft: false,
            ShowDialog: true,
            DialogHeader: "پاسخ درخواست جدید",
            selectedReqId: item.request ? item.req_id : item._id,
            selectedReqDetailId: item._id,
            selectedTitle: item.request ? item.request[0].title : item.title,
            selectedSubject: item.request ? item.request[0].Subject : item.Subject,
            selectedDesc: item.request ? item.request[0].desc : item.desc,
            selectedSender: item.Sender,
            selectedUnit:item.request ? item.request[0].Unit : item.Unit,
            selectedPriority: item.request ? item.request[0].priority : item.priority
        })
        let SCallBack = function (response) {
            that.setState({
                answers: response.data.result,
                ShowLoading: 0
            })
            for (let i = 0; i < response.data.result.length; i++) {
                if (response.data.result[i].draft) {
                    that.setState({
                        attach: response.data.result[i].attach,
                        desc: response.data.result[i].answer,
                        draft: true
                    })
                }
            }
        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
        }
        this.Server.send("CompanyApi/getRequestDetail", {
            selectedId: item.request ? item.req_id : item._id,
            user: this.state.userData.username
        }, SCallBack, ECallBack)

    }
    SetReq() {
        let that = this;
        if (!this.state.SendTo || this.state.SendTo == "") {
            this.toast.current.show({ severity: 'warn', summary: <div className="iranyekanwebmedium"></div>, detail: <div className="iranyekanwebmedium"><span> مقدار ارجاع به را پر کنید</span></div>, life: 4000 });
            return;
        }
        if (!this.state.desc || this.state.desc == "") {
            this.toast.current.show({ severity: 'warn', summary: <div className="iranyekanwebmedium"></div>, detail: <div className="iranyekanwebmedium"><span> متن پیام را پر کنید</span></div>, life: 4000 });
            return;
        }
        let UnitUsers = [];
        for (let i = 0; i < this.state.Units.length; i++) {
            if (this.state.SendTo == this.state.Units[i].lTitle) {
                for (let u of this.state.Units[i].usersList)
                    UnitUsers.push(u.username);
            }
        }
        debugger;
        let param = {
            _id: null,
            desc: this.state.desc,
            attach: this.state.attach,
            title: this.state.title,
            Priority: this.state.Priority,
            Subject: this.state.Subject,
            Reciever: isNaN(this.state.SendTo) ? UnitUsers : [this.state.SendTo],
            Unit: isNaN(this.state.SendTo) ? this.state.SendTo : false,
            Sender: this.state.userData.username,
            Copy: this.state.RequestRecieverMulti,
            status: 1,
        };
        this.setState({
            ShowLoading: 1
        })
        let SCallBack = function (response) {
            if (response.data.error) {
                that.setState({
                    ShowLoading: 0
                })
                return;
            }
            that.GetReq(1);
            that.setState({
                ShowLoading: 0
            })
        };
        let ECallBack = function (error) {
            console.log(error)
            that.setState({
                ShowLoading: 0
            })
        }
        this.Server.send("CompanyApi/setRequest", param, SCallBack, ECallBack)
    }
    SetAnswer() {
        let that = this;
        if (!this.state.desc) {
            this.toast.current.show({ severity: 'warn', summary: <div>مقداری برای پاسخ ثبت کنید</div>, life: 8000 });
            return;
        }
        debugger;

        that.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            that.setState({
                loading: 0
            })
            that.GetReq(1);
        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        let param = {};
        if (this.state.changeSender)
            param = { id: this.state.selectedReqId, answer: this.state.desc, attach: this.state.attach, username: this.state.userData.username, Sender: this.state.userData.username, Reciever: typeof this.state.SendToOther != "object" ? [this.state.SendToOther] : this.state.SendToOther, Priority: this.state.PriorityOther, changeSender: 1, draft: this.state.draft };
        else {
            let Reciever = this.state.selectedSender;
            param = { id: this.state.selectedReqId, answer: this.state.desc, attach: this.state.attach, username: this.state.userData.username, Sender: this.state.userData.username, Reciever: typeof Reciever != "object" ? [Reciever] : Reciever, draft: this.state.draft };
        }
        let UnitUsers = [];
        for (let i = 0; i < this.state.Units.length; i++) {
            if ((this.state.changeSender && this.state.SendToOther == this.state.Units[i].lTitle) || (!this.state.changeSender && this.state.selectedUnit == this.state.Units[i].lTitle)) {
                for (let u of this.state.Units[i].usersList)
                    UnitUsers.push(u.username);
            }
        }
        param.RecieverGroup = UnitUsers;
        debugger;
        this.Server.send("CompanyApi/SetAnswer", param, SCallBack, ECallBack)

    }
    EndReq(item){
        if(!this.state.confirmDialog){
            this.setState({
                ItemTemp:item,
                confirmDialog: true,
                end:1
            })
            return;
        }
        let that = this;
                let param = {
                  token: localStorage.getItem("api_token"),
                  _id: this.state.ItemTemp.req_id||this.state.ItemTemp._id,
                  End: 1
                };
                let SCallBack = function (response) {
                  that.setState({
                    ItemTemp:null,
                    confirmDialog: false,
                    end:0,
                    ShowLoading: 0
                  })
                  that.GetReq(1);
                };
                let ECallBack = function (error) {
                    that.setState({
                        ItemTemp:null,
                        confirmDialog: false,
                        end:0,
                        ShowLoading: 0
                   })
                }
                this.Server.send("CompanyApi/setRequest", param, SCallBack, ECallBack)
      }
      DelReq(item) {
        if(!this.state.confirmDialog){
            this.setState({
                ItemTemp:item,
                confirmDialog: true,
                end:0
            })
            return;
        }
        let that = this;
                let param = {
                  token: localStorage.getItem("api_token"),
                  _id: this.state.ItemTemp.req_id||this.state.ItemTemp._id,
                  del: 1
                };
                let SCallBack = function (response) {
                    that.setState({
                        ItemTemp:null,

                        confirmDialog: false,
                        end:0,
                        ShowLoading: 0
                   })
                  that.GetReq(1);
                };
                let ECallBack = function (error) {
                    that.setState({
                        ItemTemp:null,

                        confirmDialog: false,
                        end:0,
                        ShowLoading: 0
                   })
                }
                this.Server.send("CompanyApi/setRequest", param, SCallBack, ECallBack)
      }
    render() {

        return (
            !this.state.ShowLoading ?
                <div>
                    <div>
                        <Header credit={this.state.credit} noName={1} ComponentName="سیستم پشتیبانی" />

                    </div>
                    <div>
                        <Toast ref={this.toast} position="top-right" style={{ fontFamily: 'iranyekanwebmedium', textAlign: 'right' }} />


                        <div style={{ textAlign: 'center', padding: 10 }}>
                            {this.state.userData &&
                                <div style={{ display: 'flex', justifyContent: 'spaceBetween', alignItems: 'center', background: 'lavender', padding: 15, marginBottom: 10 }}>
                                    <div style={{ width: '70%', textAlign: 'center' }}>
                                        <div style={{ fontFamily: 'iranyekanwebmedium' }}>{this.state.userData.name}</div>
                                        <div style={{ fontFamily: 'iranyekanwebmedium' }}>{this.state.userData.username}</div>
                                        <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 4,background:'rebeccapurple' }} onClick={() => { this.setState({ ShowDialog: true, DialogHeader: "ثبت درخواست جدید" }) }}>
                                            <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  > ثبت درخواست / سوال</span>
                                        </Button>             
                                        <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 4,background:'brown' }} onClick={() => { this.setState({search:'',SendToFind:null});this.GetReq(); }}>
                                            <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  > به روزرسانی</span>
                                        </Button> 
                                                       </div>
                                    <div style={{ width: '30%' }}>
                                        {this.state.userData.profile_pic ?

                                            <img src={this.state.userData.profile_pic} style={{ height: 100 }} />
                                            :
                                            this.state.userData.gender == "زن" ?
                                                <img src={this.state.absoluteUrl + 'nophoto-woman.png'} style={{ height: 100 }} />
                                                :
                                                <img src={this.state.absoluteUrl + 'nophoto-man.png'} style={{ height: 100 }} />



                                        }
                                    </div>

                                </div>
                            }
                            {this.state.userData?.level == "1"  && this.state.userData?.map == "مدیریت کل" &&
                                <div>
                                     
                                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                                        
                                            <div style={{width:'30%'}}>
                                                <Button className="iranyekanwebmedium"  style={{  padding: 4 }} onClick={() => { this.setState({SendToFind:null});this.GetReq(0,this.state.search) }}>
                                                    <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  > جستجو</span>
                                                </Button>   
                                            </div>
                                            <div style={{ textAlign: 'right',width:'70%' }}>
                                                <InputText value={this.state.search} keyboardType="default" placeholder="جستجو بر اساس شماره درخواست" name="search" onChange={(text) => {
                                                        this.setState({
                                                            search: text.target.value
                                                        })
                                                        
                                                    }} style={{ textAlign: "center", fontFamily: 'iranyekanwebmedium', width: '100%',height:37 }} />
                                            </div> 
                                            
                                </div>
                                <div style={{ textAlign: 'right', direction: 'rtl',width:'100%' }}>
                                                <label className="iranyekanwebmedium" style={{ marginTop: 10,fontSize:12 }}>جستجو بر اساس واحد</label>
                                                <select style={{ width: '100%', height: 30 }} placeholder="" className="form-control iranyekanwebmedium" id={this.state.SendToFind} name="SendToOther" value={this.state.SendToFind} onChange={(event) => { this.setState({ SendToFind: event.target.value,search:'' });this.GetReq(null,null,event.target.value) }} >
                                                    <option value="" ></option>
                                                    {this.state.SendToArray && this.state.SendToArray.map((item, index) => {
                                                        return (
                                                            <option value={item.value} >{item.desc}</option>

                                                        )
                                                    })}
                                                </select>

                                            </div>
                                </div>   
                            }
                                

                            {this.state.myReqs.length == 0 ?

                                <div className="iranyekanwebmedium" style={{ marginTop: 50 }}>
                                    درخواستی پیدا نشد
                            </div>

                                :
                                <div style={{ textAlign: 'right' }}>
                                    {this.state.myReqs && this.state.myReqs.length != 0 && this.state.myReqs.map((item, index) => {
                                        if((item.request && item.request[0]) || item.number){
                                            
                                        let header = <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                            <div style={{ width: "50%" }}>

                                                <span style={{ fontSize: 11 }} >آخرین ارسال :</span>  <span style={{ fontSize: 13 }}> {item.sender[0] && item.sender[0].name} </span>

                                            </div>
                                            <div style={{ width: "25%" }} className="iranyekanwebmedium" style={{ fontSize: 13 }}>
                                                {item.request ? item.request[0]?.Date : item.Date}
                                            </div>

                                            <div style={{ width: "25%" }} className="iranyekanwebmedium" style={{ fontSize: 13 }}>
                                                {item.request ? item.request[0]?.Time : item.Time}

                                            </div>
                                            <div>

                                            </div>
                                        </div>;
                                        return (
                                            <Panel header={header} style={{ marginTop: 10 }}>
                                                <div style={{ direction: 'rtl', textAlign: 'right', padding: 4 }}>

                                                    <div>

                                                    <span style={{ fontSize: 14,color: ((item.request && item.request[0]?.status == 0) || item.status == 0 ) ? "red" :"green" }}> {item.request ? (item.request[0]?.status ? "جاری" : "خاتمه یافته") : (item.status ? "جاری" : "خاتمه یافته")} </span>

                                                    </div>
                                                    <div>

                                                        <span style={{ fontSize: 11 }} >شماره درخواست :</span>  <span style={{ fontSize: 14 }}> {item.request ? item.request[0].number : item.number} </span>

                                                    </div>
                                                    {item.unitData[0] &&
                                                        <div>
                                                            <span style={{ fontSize: 11 }} >واحد دریافت کننده :</span>  <span style={{ fontSize: 14 }}> {item.unitData[0] && item.unitData[0].fTitle} </span>

                                                        </div>
                                                    }
                                                    <div>
                                                        {((item.request && item.request[0].Subject) || item.Subject) &&
                                                            <div className="iranyekanwebmedium">
                                                            {item.request ? item.request[0].Subject : item.Subject}
                                                            </div>
                                                        }
                                                        
                                                        {((item.request && item.request[0].title) || item.Subject) &&
                                                            <div className="iranyekanwebmedium">
                                                            {item.request ? item.request[0]?.title : item.title}
                                                            </div>
                                                        }
                                                        <div className="iranyekanwebmedium" style={{whiteSpace:'pre-line'}}>
                                                            {item.request ? item.request[0]?.desc : item.desc}
                                                        </div>
                                                        <div style={{display:'flex',justifyContent:'space-between'}}>
                                                            <div>
                                                                {((item.request && item.request[0].status) || item.status) != 0 &&
                                                                    <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 4,backgroundColor:'green' }} onClick={() => { this.GetAnswer(item) }}>
                                                                        <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  >پاسخ</span>
                                                                    </Button>
                                                                }
                                                            
                                                            </div>
                                                            <div>
                                                             {this.state.userData?.level == "1" && ((item.request && item.request[0].status) || item.status) != 0 && this.state.userData?.map == "مدیریت کل" &&
                                                             <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 4,backgroundColor:'orange' }} onClick={() => { this.EndReq(item) }}>
                                                             <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  >پایان</span>
                                                             </Button>
                                                             }   
                                                            
                                                            {this.state.userData?.level == "1" && this.state.userData?.map == "مدیریت کل" &&
                                                                <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 4,backgroundColor:'red' }} onClick={() => { this.DelReq(item) }}>
                                                                    <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  >حذف</span>
                                                                </Button>
                                                            }
                                                            </div>

                                                            
                                                        </div>
                                                        

                                                    </div>



                                                </div>

                                            </Panel>

                                        )

                                    }


                                    })
                                    }
                                </div>

                            }



                        </div>



                        
                        <Dialog header={this.state.end? "پایان درخواست" :"حذف درخواست"} visible={this.state.confirmDialog} maximized={true} onHide={() => {
                            this.setState({
                                confirmDialog:false
                            })
                        }
                        }>

                        <p className="iranyekanwebmedium" style={{textAlign:'center',marginTop:100}}>آیا از {this.state.end? "پایان درخواست" :"حذف درخواست"} مطمئنید ؟</p>

                        <div style={{display:'flex',justifyContent:'space-evenly'}} >
                            <div>
                            <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 10 }} onClick={() => { 
                                if(this.state.end){
                                    this.EndReq()
                                }else{
                                    this.DelReq()

                                } }}>
                                                <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  >بله</span>
                                            </Button>
                            </div>
                            <div>
                            <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 10 }} onClick={() => { this.setState({confirmDialog:false,ItemTemp:null}) }}>
                                                <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  >خیر</span>
                                            </Button>
                            </div>
                        </div>
                        </Dialog>

                        <Dialog header={this.state.DialogHeader} visible={this.state.ShowDialog} maximized={true} onHide={() => {
                            this.setState({
                                ShowDialog: false,
                                selectedReqId: null,
                                selectedReqDetailId: null,
                                selectedTitle: null,
                                selectedDesc: null,
                                changeSender:false
                            });
                        }
                        }>
                            <div>
                                {this.state.selectedReqId &&

                                    <div style={{ textAlign: 'right', borderRadius: 5, padding: 14,backgroundColor:'#eeeeee38' }}>
                                        {this.state.selectedSubject &&
                                            <div className="iranyekanwebmedium" style={{display:'none'}}>{this.state.selectedSubject}</div>
                                        }
                                        {this.state.selectedTitle &&
                                            <div className="iranyekanwebmedium">{this.state.selectedTitle}</div>
                                        }
                                        <p className="iranyekanwebmedium" style={{whiteSpace:'pre-line'}}>{this.state.selectedDesc}</p>

                                    </div>


                                }
                                {this.state.selectedReqId &&

                                    <div style={{textAlign: 'right', borderRadius: 5, padding: 4 }}>

                                        {this.state.answers && this.state.answers.map((item, index) => {
                                            let header = <div style={{ display: 'flex',justifyContent:'space-between' }}>
                                                            <div style={{width:'15%'}} >
                                                                <i className="fa fa-check" style={{color:item.read ? '#00d000' : 'gainsboro',fontSize:11}}  />
                                                                <i className="fa fa-check" style={{color:item.read ? '#00d000' : 'gainsboro',fontSize:11}}  />
                                                            </div>
                                                            <div style={{ width: '35%',fontSize: 13 }}  className="iranyekanwebmedium"> {item.Sender[0].name||item.Sender[0].username} </div> 
                                                            <div style={{ width: '25%',fontSize: 13 }} className="iranyekanwebmedium"> {item.Date} </div> 
                                                             <div style={{ width: '25%',fontSize: 13 }} className="iranyekanwebmedium"> {item.Time} </div>


                                                        </div>
                                            return (
                                                
                                                <Panel header={header} style={{ marginTop: 10 }}>
                                                <div className="iranyekanwebmedium" style={{ direction: 'rtl', textAlign: 'right', backgroundColor: (item.user==this.state.userData.username) ? '#fff' : '#cdffc9', padding: 4 }}>


                                                {item.answer}



                                                </div>

                                            </Panel>
                                            )
                                            
                                        })}

                                    </div>


                                }

                                <div style={{ padding: 10 }}>
                                    {!this.state.selectedReqId &&
                                        <div style={{ textAlign: 'right', marginTop: 15 }}>
                                            <label style={{ textAlign: "center", fontFamily: 'iranyekanwebmedium', width: '100%' }}>عنوان</label>

                                            <InputText value={this.state.title} keyboardType="default" placeholder="" name="title" onChange={(text) => {
                                                this.setState({
                                                    title: text.target.value
                                                })
                                            }} style={{ textAlign: "center", fontFamily: 'iranyekanwebmedium', width: '100%' }} />

                                        </div>
                                    }
                                        <div className="col-12 col-lg-3" style={{ textAlign: 'right', direction: 'rtl' }}>
                                            <label className="iranyekanwebmedium" style={{ marginTop: 10 }}>{this.state.SubjectArray?.title}</label>
                                            <select disabled={this.state.selectedReqId} style={{ width: '100%', height: 40 }} placeholder="" className="form-control iranyekanwebmedium" id={this.state.Subject} name="SendTo" value={this.state.Subject} onChange={(event) => { this.setState({ Subject: event.target.value }) }} >
                                                <option value="" ></option>
                                                {this.state.SubjectArray && this.state.SubjectArray.values.map((item, index) => {
                                                    return (
                                                        <option value={item.value} >{item.desc}</option>

                                                    )
                                                })}
                                            </select>

                                        </div>
                                        <div className="col-12 col-lg-3" style={{ textAlign: 'right', direction: 'rtl' }}>
                                            <label className="iranyekanwebmedium" style={{ marginTop: 10 }}>{this.state.PriorityArray?.title}</label>
                                            <select disabled={this.state.selectedReqId} style={{ width: '100%', height: 40 }} placeholder="" className="form-control iranyekanwebmedium" id={this.state.Priority} name="Priority" value={this.state.Priority} onChange={(event) => { this.setState({ Priority: event.target.value }) }} >
                                                <option value="" ></option>
                                                {this.state.PriorityArray && this.state.PriorityArray.values.map((item, index) => {
                                                    return (
                                                        <option value={item.value} >{item.desc}</option>

                                                    )
                                                })}
                                            </select>

                                        </div>

                                    <div style={{ textAlign: 'right' }}>
                                        <label className="iranyekanwebmedium" style={{ marginTop: 10 }}>{this.state.selectedReqId ? "متن پاسخ" : "متن پیام"}</label>

                                        <div  >

                                            <textarea className="form-control iranyekanwebmedium" autocomplete="off" style={{ border: '1px solid #ced4da', borderRadius: 5, textAlign: 'right', width: '100%', height: 150 }} type="number" id="desc" value={this.state.desc} name="desc" onChange={(e) => this.setState({ desc: e.target.value })} required />
                                        </div>
                                    </div>
                                    {!this.state.selectedReqId &&
                                        <div className="col-12 col-lg-3" style={{ textAlign: 'right', direction: 'rtl' }}>
                                            <label className="iranyekanwebmedium" style={{ marginTop: 10 }}>{this.state.SendToTitle}</label>
                                            <select style={{ width: '100%', height: 40 }} placeholder="" className="form-control iranyekanwebmedium" id={this.state.SendTo} name="SendTo" value={this.state.SendTo} onChange={(event) => { this.setState({ SendTo: event.target.value }) }} >
                                                <option value="" ></option>
                                                {this.state.SendToArray && this.state.SendToArray.map((item, index) => {
                                                    return (
                                                        <option value={item.value} >{item.desc}</option>

                                                    )
                                                })}
                                            </select>

                                        </div>
                                    }

                                        

                                    {this.state.selectedReqId &&
                                        <div style={{ textAlign: 'right' }}>
                                            {this.state.userData?.level == "1"  &&
                                                <div className="col-12" style={{ textAlign: 'right', display: 'flex', alignItems: 'end', padding: 0, marginRight: 5, direction: 'rtl' }}>
                                                    <Checkbox inputId="draft" value={this.state.draft} checked={this.state.draft} onChange={e => this.setState({ draft: e.checked })}></Checkbox>
                                                    <label htmlFor="draft" className="p-checkbox-label IRANYekan" style={{ paddingRight: 5 }}> پیشنویس</label>
                                                </div>
                                            }
                                            {this.state.userData?.level == "1" &&  this.state.userData?.map == "مدیریت کل" &&
                                                <div className="col-12" style={{ textAlign: 'right', display: 'flex', alignItems: 'end', padding: 0, marginRight: 5, direction: 'rtl' }}>
                                                    <Checkbox inputId="changeSender" value={this.state.changeSender} checked={this.state.changeSender} onChange={e => this.setState({ changeSender: e.checked })}></Checkbox>
                                                    <label htmlFor="changeSender" className="p-checkbox-label IRANYekan" style={{ paddingRight: 5 }}> ارجاع به دیگران</label>
                                                </div>
                                            }
                                            
                                        </div>
                                    }

                                    {this.state.changeSender &&
                                        <div >
                                            <div className="col-12 col-lg-3" style={{ textAlign: 'right', direction: 'rtl' }}>
                                                <label className="iranyekanwebmedium" style={{ marginTop: 10 }}>{this.state.PriorityArray?.title}</label>
                                                <select style={{ width: '100%', height: 40 }} placeholder="ارجاع به ..." className="form-control iranyekanwebmedium" id={this.state.PriorityOther} name="PriorityOther" value={this.state.PriorityOther} onChange={(event) => { this.setState({ PriorityOther: event.target.value }) }} >
                                                    <option value="" ></option>
                                                    {this.state.PriorityArray && this.state.PriorityArray.values.map((item, index) => {
                                                        return (
                                                            <option value={item.value} >{item.desc}</option>

                                                        )
                                                    })}
                                                </select>

                                            </div>
                                            <div className="col-12 col-lg-3" style={{ textAlign: 'right', direction: 'rtl' }}>
                                                <label className="iranyekanwebmedium" style={{ marginTop: 10 }}>ارجاع به ...</label>
                                                <select style={{ width: '100%', height: 40 }} placeholder="ارجاع به ..." className="form-control iranyekanwebmedium" id={this.state.SendToOther} name="SendToOther" value={this.state.SendToOther} onChange={(event) => { this.setState({ SendToOther: event.target.value }) }} >
                                                    <option value="" ></option>
                                                    {this.state.SendToArray && this.state.SendToArray.map((item, index) => {
                                                        return (
                                                            <option value={item.value} >{item.desc}</option>

                                                        )
                                                    })}
                                                </select>

                                            </div>

                                        </div>
                                    }

                                    <div className="col-12 col-lg-3" style={{ textAlign: 'right', direction: 'rtl' }}>
                                        {this.state.selectedReqId ?
                                            <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 4 }} onClick={this.SetAnswer}>
                                                <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  >ثبت پاسخ</span>
                                            </Button>

                                            :
                                            <Button className="iranyekanwebmedium" style={{ marginTop: 20, padding: 4 }} onClick={this.SetReq}>
                                                <span className="iranyekanwebmedium" style={{ width: '100%', fontSize: 17, fontFamily: 'iranyekanwebmedium' }}  >ثبت درخواست / سوال</span>
                                            </Button>
                                        }

                                    </div>


                                </div>

                            </div>

                        </Dialog>



                    </div>
                </div>
                :
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                    <ProgressSpinner style={{ paddingTop: 150 }} />

                </div>
        );
    }
}
function mapStateToProps(state) {
    return {
        username: state.username,
        password: state.password,
        ip: state.ip,
        account: state.account,
        place: state.place,
        fullname: state.fullname,
        mobile: state.mobile
    }
}
export default connect(mapStateToProps)(Support)

