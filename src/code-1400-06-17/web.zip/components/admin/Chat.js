import React, { Component, useEffect } from 'react';
import { BrowserRouter, Route, withRouter, Redirect } from 'react-router-dom'
import './Dashboard.css'
import { io } from "socket.io-client";

import { Editor } from '@tinymce/tinymce-react';

import 'primeicons/primeicons.css';
import Server from './../Server.js'
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';

import { SelectButton } from 'primereact/selectbutton';
import { connect } from 'react-redux';
import { Loader } from 'rsuite';
import { Toast } from 'primereact/toast';
import './DataTableDemo.css';
const FilterItems = [
    { label: 'همه', value: 'All' },
    { label: 'جاری', value: "1" },

    { label: 'پایان یافته', value: "2" }



];
let ania_chat_interval = null,
    ania_chat_interval2 = null;
var socket;

class Chat extends React.Component {
    constructor(props) {
        super(props);
        this.Server = new Server();
        this.state = {
            layout: 'list',
            dashList: (this.props && this.props.location && this.props.location.state && this.props.location.state.list) ? this.props.location.state.list : [],
            dashData: (this.props && this.props.location && this.props.location.state && this.props.location.state.data) ? this.props.location.state.data : [],
            NewFactors: (this.props && this.props.location && this.props.location.state && this.props.location.state.NewFactors) ? this.props.location.state.NewFactors : null,
            NewUsers: (this.props && this.props.location && this.props.location.state && this.props.location.state.NewUsers) ? this.props.location.state.NewUsers : null,
            ChatSelected: {},
            Filter: "1",
            url: this.Server.getUrl(),
            absoluteUrl: this.Server.getAbsoluteUrl()

        }
        socket = io(this.Server.getAbsoluteUrl());
        this.toast = React.createRef();
        this.Editor = React.createRef();
        this.selectChat = this.selectChat.bind(this);
        this.EndChat = this.EndChat.bind(this);
        this.itemTemplate = this.itemTemplate.bind(this);
        this.onHideDialog = this.onHideDialog.bind(this);
        this.SetAnswer = this.SetAnswer.bind(this);
        this.getCode = this.getCode.bind(this);

    }

    componentDidMount() {
        socket.on("setChat", (data) => {
            this.getChat(this.state.visibleDialog ? data._id : null, this.state.Filter)
        });


        let param = {
            token: localStorage.getItem("api_token"),
        };
        let that = this;
        this.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            that.setState({
                loading: 0
            })
            that.setState({
                username: response.data.authData.username,
                UId: response.data.authData.userId,
                shopId: response.data.authData.shopId,
                name: response.data.authData.name || ""
            })


            that.getShop();


        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("MainApi/checktoken", param, SCallBack, ECallBack)
    }
    getShop() {
        let that = this;
        that.Server.send("AdminApi/ShopInformation", { ShopId: this.state.shopId }, function (response) {
            that.setState({
                tokenId: response.data.result[0]?.tokenId
            })
            that.getCode();


        }, function (error) {
        })
    }
    getCode() {
        let that = this;
        that.Server.send("AdminApi/getSettings", {}, function (response) {
            that.setState({
                code: response.data.result[0] ? response.data.result[0].ChatId : '',
            })
            that.getChat(null, that.state.Filter);
            /*ania_chat_interval2 = setInterval(function () {
                that.getChat(null, that.state.Filter);
            }, 10000);*/



        }, function (error) {
        })
    }


    getChat(_id, Filter) {
        let param = {
            token: localStorage.getItem("api_token"),
            sort: { "_id": -1 },
            _id: _id,
            User: 0,
            End: 'All',
            code: this.state.tokenId || this.state.code
        };
        let that = this;
        if (!_id)
            this.setState({
                loading: 1
            })
        let SCallBack = function (response) {
            if (_id) {
                that.setState({
                    loading: 0,
                    ChatSelected: response.data.result[0]
                })


            } else {
                debugger;
                that.setState({
                    loading: 0,
                    GridData: response.data.result
                })
            }




        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("ChatApi/getChat", param, SCallBack, ECallBack)

    }
    selectChat(itemSelected) {
        let that = this;
        debugger;
        this.setState({
            visibleDialog: true,
            ChatSelected: itemSelected
        })

    }
    EndChat(itemSelected) {
        let _id = itemSelected._id;
        let param = {
            token: localStorage.getItem("api_token"),
            _id: _id,
            code: this.state.code
        };
        let that = this;
        this.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            that.setState({
                loading: 0
            })
            that.getChat();





        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("ChatApi/EndChat", param, SCallBack, ECallBack)
        return false;

    }
    itemTemplate(car, layout) {
        if (!car)
            return (
                <div className="p-col-12 p-md-3">
                    <div></div>
                </div>
            );

        if (layout === 'list') {
            return (
                <div className="row" >
                    <div className="col-lg-12 " >
                        <div className="row" style={{ margin: 20 }}>

                            <div className="col-lg-9 col-12 yekan" style={{ cursor: 'pointer', textAlign: "right", padding: 10, borderRadius: 10 }} onClick={() => { this.selectChat(car) }} >
                                <p className="yekan" >{car.TodayTime} : {car.TodayDate}</p>

                                <p className="yekan" style={{ fontSize: 25, color: 'blue', whiteSpace: 'pre-wrap' }}>

                                <div className="yekan" dangerouslySetInnerHTML={{ __html: car.text }}  />



                                </p>



                                {car.chats_detail &&
                                    <div className="yekan" dangerouslySetInnerHTML={{__html:car.chats_detail[car.chats_detail.length - 1]?.text}}  />
                                }



                            </div>

                            <div className="col-lg-3 col-12" style={{ display: 'none' }}>
                                {car.End ?
                                    <div>
                                        <p className="yekan" style={{ color: 'red' }}>پایان یافته</p>

                                    </div>
                                    :
                                    <div>

                                        <button className="btn btn-danger yekan" onClick={() => { this.EndChat(car) }} style={{ marginTop: "5px", marginBottom: "5px", float: 'left' }}>پایان گفتگو </button>

                                    </div>
                                }
                            </div>




                        </div>
                    </div>

                </div>
            );
        }
        if (layout === 'grid') {
            return (
                <div className="p-col-12 p-md-3">
                    <div>{car.brand}</div>
                </div>
            );
        }
    }

    onHideDialog(event) {

        clearInterval(ania_chat_interval);
        let that = this;
        //ania_chat_interval2 = setInterval(function () {

        that.getChat(null, that.state.Filter);
        //}, 10000);

        this.getChat(null, that.state.Filter);

        this.setState({
            visibleDialog: false,
            ChatSelected: {}
        });
    }
    SetAnswer() {
        let param = {
            token: localStorage.getItem("api_token"),
            sort: { TodayDate_C: -1 },
            UId: this.state.UId,
            _id: this.state.ChatSelected._id,
            value: this.Editor.current.getContent(),
            userSend: 0,
            code: this.state.code
        };
        let that = this;
        this.setState({
            loading: 1
        })
        let SCallBack = function (response) {
            that.setState({
                loading: 0
            })
            that.toast.current.show({ severity: 'success', summary: <div>پاسخ با موفقیت ارسال شد</div>, life: 8000 });
            that.getChat();
            //that.onHideDialog();


        };
        let ECallBack = function (error) {
            that.setState({
                loading: 0
            })
            console.log(error)
        }
        this.Server.send("ChatApi/setChat", param, SCallBack, ECallBack)
    }

    render() {


        return (
            <div style={{ direction: 'rtl' }}>


                {this.state.loading == 1 &&
                    <div style={{ position: 'fixed', zIndex: 2000, top: 10, left: '50%', padding: '2px 20px' }}>
                        <Loader content="" className="yekan" />
                    </div>
                }
                <Toast ref={this.toast} position="top-left" style={{ fontFamily: 'YekanBakhFaBold', textAlign: 'right' }} />

                <div className="row justify-content-center">

                    <div className="col-12" >
                        <div className="row" style={{ alignItems: 'flex-start',marginTop:20,background:'#eeeeee52' }} >
                            <div className="col-9" style={{display:'none'}} >
                                <div style={{ textAlign: 'right', marginBottom: 10 }}>
                                    <SelectButton value={this.state.Filter} options={FilterItems} style={{ fontFamily: 'Yekan' }} className="yekan" onChange={(e) => { this.setState({ Filter: e.value || "1" }); this.getChat(null, e.value || "1") }}></SelectButton>

                                </div>

                            </div>
                            <div className="col-3" style={{display:'none'}} >
                                <div style={{ textAlign: 'right', marginBottom: 10 }}>

                                    <button className="btn btn-info yekan" onClick={() => { this.getChat(null, this.state.Filter) }} style={{ marginTop: "5px", marginBottom: "5px" }}><i className="fas fa-sync" /></button>
                                </div>

                            </div>
                            <div className="col-3">

                                <DataView value={this.state.GridData} layout={this.state.layout} paginator={false} itemTemplate={this.itemTemplate}></DataView>
                            </div>


                            <div className="col-9">
                                {this.state.ChatSelected.text ?
                                <div className="row" style={{ margin: 20,maxHeight:600,overflow:'auto' }}>

                                    <div className="col-lg-12 col-12 yekan" style={{ textAlign: "right", marginBottom: 10, borderRadius: 10 }}>
                                        
                                        <div style={{ fontSize: 25, color: '#fff', width: 'fit-content', padding: 6, borderRadius: 10, background: '#7b7db9' }}>

                                        <p className="yekan"  style={{  color: '#ffffff80' }} >{this.state.ChatSelected.TodayTime} : {this.state.ChatSelected.TodayDate}</p>

                                        <p className="yekan"  style={{ fontSize: 19, color: '#fff' }} >

                                            <div className="yekan" dangerouslySetInnerHTML={{ __html: this.state.ChatSelected.text }}  />

                                            </p>
                                        </div>


                                    </div>


                                    <div className="col-9" style={{ textAlign: 'right' }}>
                                        {this.state.ChatSelected.chats_detail && this.state.ChatSelected.chats_detail.map((v, i) => {
                                            let style = v.userSend ? { fontSize: 25, width: 'fit-content', padding: 6, borderRadius: 10,color:'#fff', background: '#7b7db9', marginBottom: 5, clear: 'both' } : { fontSize: 25, color: 'blue', width: 'fit-content', padding: 6, borderRadius: 10, background: '#eee', marginBottom: 5, float: 'left', clear: 'both' }
                                            return (
                                                <div style={style}>
                                                    {v.userSend ?
                                                        <p className="yekan" style={{ textAlign: 'right', color: '#ffffff80' }}>{v.TodayTime} : {v.TodayDate}</p>
                                                        :
                                                        <p className="yekan" style={{ textAlign: 'left', color: '#00000059' }}>{v.TodayTime} : {v.TodayDate}</p>
                                                    }
                                                    {v.userSend ?
                                                        <p className="yekan" style={{ whiteSpace: 'pre-wrap', fontSize: 19, color: '#fff', textAlign: 'right' }}>
                                                            <div className="yekan" dangerouslySetInnerHTML={{ __html: v.text }}  />
                                                        </p>
                                                        :
                                                        <p className="yekan" style={{ whiteSpace: 'pre-wrap', fontSize: 19, textAlign: 'left' }}>
                                                            {v.read ?
                                                                <img src='/read.png' style={{ width: 16 }} />

                                                                :
                                                                <img src='/unread.png' style={{ width: 16 }} />
                                                            }
                                                            <div className="yekan" dangerouslySetInnerHTML={{ __html: v.text }}  />

                                                            </p>
                                                    }

                                                </div>
                                            )
                                        })
                                        }
                                    </div>
                                    {!this.state.ChatSelected.End &&
                                        <div className="col-lg-12 col-12 yekan" style={{ textAlign: "center" }}>
                                            <div >

                                            <Editor
                                                onInit={(evt, editor) => this.Editor.current = editor}
                                                apiKey="lrmgs4af4ytto19pzokzobruax5zn8yhqnjw3gw7h4r3i0om"
                                                init={{
                                                    plugins: "emoticons",
                                                    directionality: "rtl",
                                                    toolbar: "emoticons",
                                                    toolbar_location: "bottom",
                                                    menubar: false,
                                                  }}
                                            />
                                            </div>
                                            <div style={{ textAlign: 'right' }}>
                                                <button className="btn btn-primary irsans" onClick={this.SetAnswer} style={{ width: "200px", marginTop: "20px", marginBottom: "20px" }}> اعمال </button>
                                            </div>
                                        </div>

                                    }


                                </div>
                                :
                                <div style={{textAlign:'center',marginTop:150}}>
                                    <i class="fas fa-comment-minus" style={{fontSize:60,marginBottom:60,color:'#eee'}}></i>
                                    <p className="yekan" style={{fontSize:25,color:'#eee'}}>گفتگویی را انتخاب کنبد</p>
                                </div>
                            }

                            </div>
                        </div>


                    </div>



                </div>
                

            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        username: state.username
    }
}
export default withRouter(
    connect(mapStateToProps)(Chat)
);
