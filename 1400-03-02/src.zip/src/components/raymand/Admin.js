import React, { Component } from 'react';
import { Badge } from 'primereact/badge';

import Server from '../Server.js'
import { connect } from "react-redux"
import Header from '../Header.js'
import { withRouter, Redirect, Link } from 'react-router-dom'
import Turnover from './Turnover.js'
import { ProgressSpinner } from 'primereact/progressspinner';

class Admin extends React.Component {       
  constructor(props){
    super(props);  
    this.Server = new Server();
    this.state={
      AccountNumber:this.props.location.search.split("account=")[1],
      Place:this.props.place,
      listViewData:[],
      Sort:"",
      loading:false,
      IsSeller:-1
    }     
    
  }
  componentDidMount() {
    let that = this;
    let param = {
      token: localStorage.getItem("api_token"),
    };
    this.setState({
      loading: 1
    })
    let SCallBack = function (response) {
      that.setState({
        UId: response.data.authData.userId,
        loading: 0
      })
      that.getuserInformation(response.data.authData.userId);
    };
    let ECallBack = function (error) {
      that.setState({
        loading: 0
      })
      console.log(error)
    }
    this.Server.send("MainApi/checktoken", param, SCallBack, ECallBack)
  }
  getuserInformation(UId){

    let that = this;
    let param = {
      user_id:UId
    };
    this.setState({
      loading: 1
    })
    let SCallBack = function (response) {
      that.setState({
        shopId:response.data.result[0].shopId,
        loading: 0
      })
      that.getShop(response.data.result[0].shopId);
    };
    let ECallBack = function (error) {
      that.setState({
        loading: 0
      })
      console.log(error)
    }
    this.Server.send("MainApi/getuserInformation", param, SCallBack, ECallBack)

  }
  getShop(shopId){
    if(!shopId){
      this.setState({
        IsSeller:0
      })
      return;
    }
    let that = this;
    let param = {
      ShopId:shopId
    };
    this.setState({
      loading: 1
    })
    let SCallBack = function (response) {
      that.setState({
        shop:response.data.result[0],
        credit:response.data.result[0]?.credit||0,
        loading: 0,
        IsSeller:1
      })
    };
    let ECallBack = function (error) {
      that.setState({
        loading: 0
      })
      console.log(error)
    }
    this.Server.send("AdminApi/ShopInformation", param, SCallBack, ECallBack)

  }
  render() {         
   
  
    return (   

      <div>
            <Header credit={this.state.credit} ComponentName="پذیرندگان" />

             
       <div> 
       <div style={{marginTop:40,maxHeight:'calc(100% - 210px)',overflow:'auto'}}>    
        {this.state.IsSeller == 0 &&
            <div>
            <p style={{ fontFamily: 'YekanBakhFaMedium', textAlign: 'center',color:'red' }}>
               شما به عنوان پذیرنده در سیستم تعریف نشده اید
             </p>
             <p style={{ fontFamily: 'YekanBakhFaMedium', textAlign: 'center' }}>
               برای ثبت نام به عنوان پذیرنده و استفاده از امکانات فروش نقدی و اقساطی محصولات خود به صورت حضوری و آنلاین با پشتیبانان سیستم تماس بگیرید
             </p>

            </div>
        }
        {this.state.IsSeller == 1 &&
            <div>
            <p style={{ fontFamily: 'YekanBakhFaMedium', textAlign: 'center',color:'green',fontSize:17,direction:'rtl' }}>
               موجودی مهر کارت فروشگاه {this.state.shop?.name} : <br/> <span style={{fontSize:23}}>{this.state.credit.toString().replace(",", "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")} ریال  </span>
             </p>
             <hr style={{borderColor:'#eaeaea42'}} />
             
              <Turnover shop="1" shopId={this.state.shopId} />
            </div>
        }
        {this.state.IsSeller == -1 &&
        <div style={{display:'flex',justifyContent:'center',alignItems:'center',height:'100%'}}>
            <ProgressSpinner style={{paddingTop:150}}/>
        </div>
        
        }
             
        </div>
       </div>
          
    </div>
    );
  }
}
function mapStateToProps(state) {        
  return {
    username : state.username,
    password : state.password,
    ip : state.ip,
    account:state.account,
    place:state.place,
    fullname : state.fullname,
    mobile : state.mobile
  }
}
export default connect(mapStateToProps)(Admin)  

