import React, { Component } from 'react';
import axios from 'axios'
import { connect } from 'react-redux';
import Server from '../Server.js'
import Header from '../Header.js'
import { SelectButton } from 'primereact/selectbutton';
import { ToggleButton } from 'primereact/togglebutton';



import { withRouter, Route, Link, Redirect } from 'react-router-dom'
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Toast } from 'primereact/toast';
import Swiper from 'react-id-swiper';
import 'swiper/css/swiper.css';
import { ProgressSpinner } from 'primereact/progressspinner';

const params5 = {
  autoplay: {
    delay: 5000,
    disableOnInteraction: false
  },
  loop: 1,
  centeredSlides: true,
  slidesPerView: 'auto',
  coverflowEffect: {
    rotate: 50,
    stretch: 0,
    depth: 100,
    modifier: 1,
    slideShadows: true
  },
  pagination: {
    el: '.swiper-pagination'
  }
}
class Reserve extends React.Component {
  constructor(props) {
    super(props);
    this.myRef = React.createRef()   // Create a ref object
    this.Server = new Server();
    localStorage.removeItem("food");
    this.state = {
      activePage: 1,
      CurrentTab: 1,
      credit: 0,
      mounth:["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"],
      absoluteUrl: this.Server.getAbsoluteUrl(),
      url: this.Server.getUrl()

    }


  }
  componentDidMount() {
    this.GetReserve();
  }

  GetReserve() {
    let that = this;
    let param = {
      token: localStorage.getItem("api_token"),
      number: "1"
    };
    this.setState({
      loading: 1
    })
    let SCallBack = function (response) {
      that.setState({
        GridDataReserve: response.data.result[0]
      })
      that.setState({
        loading: 0
      })
      that.GetReserveDetails("1")
    };
    let ECallBack = function (error) {
      that.setState({
        loading: 0
      })
    }
    this.Server.send("AdminApi/GetReserve", param, SCallBack, ECallBack)
  }

  GetReserveDetails(number) {
    let that = this;
    let param = {
      number: number
    };
    this.setState({
      loading: 1
    })
    let SCallBack = function (response) {
      let Mounth={
        one:[],
        two:[],
        three:[],
        four:[],
        five:[],
        six:[],
        seven:[],
        eight:[],
        nine:[],
        ten:[],
        eleven:[],
        toelve:[]
      };
      for(let item of response.data.result){
        item.Mounth = that.state.mounth[item.day.split("_")[1]];
        item.MounthNum = parseInt(item.day.split("_")[1]);
        item.Day = item.day.split("_")[2];
        item.Year = item.day.split("_")[0];
        item.price = item.price || that.state.GridDataReserve.price;
        item.value = item.day;
        item.label =  item.Day;
        if(item.MounthNum == 1)
          Mounth.one.push(item)
        if(item.MounthNum == 2)
          Mounth.two.push(item)
        if(item.MounthNum == 3)
          Mounth.three.push(item)
        if(item.MounthNum == 4)
          Mounth.four.push(item)
        if(item.MounthNum == 5)
          Mounth.five.push(item)
        if(item.MounthNum == 6)
          Mounth.six.push(item)
        if(item.MounthNum == 7)
          Mounth.seven.push(item)
        if(item.MounthNum == 8)
          Mounth.eight.push(item)  
        if(item.MounthNum == 9)
          Mounth.nine.push(item)
        if(item.MounthNum == 10)
          Mounth.ten.push(item)
        if(item.MounthNum == 11)
          Mounth.eleven.push(item)
        if(item.MounthNum == 12)
          Mounth.toelve.push(item)
      }
      that.setState({
        loading: 0,
        TableRecords:response.data.result,
        Mounth:Mounth
      })

    };
    let ECallBack = function (error) {
      that.setState({
        loading: 0
      })
    }
    this.Server.send("AdminApi/GetReserveDetails", param, SCallBack, ECallBack)
  }

  render() {
    if (this.state.page) {
      return <Redirect to={this.state.page} />;
    }
    return (

      <div style={{ height: '100%' }}>
        <Header ComponentName="رزرو ویلا" />

        {!this.state.ShowLoading ?
        <div>
        <div style={{textAlign:'center',display:'flex',justifyContent:'center',marginTop:20}} >
          <div style={{width:'95%'}}>
          {this.state.GridDataReserve &&
              <Swiper {...params5} >
                              <div>
                              <img src={this.state.absoluteUrl +  (this.state.GridDataReserve.pic ? this.state.GridDataReserve.pic?.split("public")[1] : 'nophoto.png')} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }}  />

                              </div>
                              <div>
                              <img src={this.state.absoluteUrl +  (this.state.GridDataReserve.extraPic1 ? this.state.GridDataReserve.extraPic1?.split("public")[1]: 'nophoto.png')} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }}  />

                              </div>
                              <div>
                              <img src={this.state.absoluteUrl +  (this.state.GridDataReserve.extraPic2 ? this.state.GridDataReserve.extraPic2?.split("public")[1]: 'nophoto.png')} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }}  />

                              </div>
                              <div>
                              <img src={this.state.absoluteUrl +  (this.state.GridDataReserve.extraPic3 ? this.state.GridDataReserve.extraPic3?.split("public")[1]: 'nophoto.png')} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }}  />

                              </div>
                              <div>
                              <img src={this.state.absoluteUrl +  (this.state.GridDataReserve.extraPic4 ? this.state.GridDataReserve.extraPic4?.split("public")[1]: 'nophoto.png')} style={{ borderRadius: 12, whiteSpace: 'pre-wrap',maxHeight:200,width:'100%' }}  />

                              </div>
                            </Swiper>
                        }

                  </div>
          </div>
          <div className="no-scroll-bar" style={{display:'inline',flexWrap:'wrap',overflow:'auto',direction:'rtl'}} >
          {this.state.Mounth && this.state.Mounth.three && this.state.Mounth.three.length > 0 &&
            <div style={{border:'1px solid #eee',textAlign:'center',padding:10,position:'relative'}}>
              <p className="YekanBakhFaMedium" style={{textAlign:'center'}}>{this.state.Mounth.three[0].Mounth}</p>
            <div style={{display:'flex',justifyContent:'flex-end',flexWrap:'wrap'}}>
              { this.state.Mounth.three.map((item,index) =>{
                debugger;
                  return(
                    <ToggleButton style={{width:'20%',direction:'rtl'}} checked={item.checked} offLabel={item.label}  onLabel={item.label} onChange={(e) => {
                      item.checked = e.value
                      debugger;
                    }
                  } />
                  )
                
              })}

          
            </div>
            </div>
          }
          {this.state.Mounth && this.state.Mounth.four && this.state.Mounth.four.length > 0 &&
            <div style={{border:'1px solid #eee',textAlign:'center',padding:10,position:'relative'}}>
              <p className="YekanBakhFaMedium" style={{textAlign:'center'}}>{this.state.Mounth.four[0].Mounth}</p>
            <div style={{display:'flex',justifyContent:'flex-end',flexWrap:'wrap'}}>
              { this.state.Mounth.four.map((item,index) =>{
                debugger;
                  return(
                    <ToggleButton style={{width:'20%',direction:'rtl'}} checked={item.checked} offLabel={item.label}  onLabel={item.label} onChange={(e) => {
                      item.checked = e.value
                      debugger;
                    }
                  } />
                  )
                
              })}

          
            </div>
            </div>
          }
          </div>
          

        </div>
        :
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center',height:'100%' }}>
          <ProgressSpinner style={{ paddingTop: 150 }} />
        </div>
      }
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    username: state.username,
    password: state.password,
    ip: state.ip,
    account: state.account,
    place: state.place,
    fullname: state.fullname,
    mobile: state.mobile
  }
}
export default connect(mapStateToProps)(Reserve)

