import React, { useRef } from 'react';
import { connect } from 'react-redux';
import { withRouter, Redirect, Link } from 'react-router-dom'

import { Button } from 'primereact/button';


import Server from './Server.js'


let Cound = 0;

class Header extends React.Component {
	constructor(props) {
		super(props);
		this.op = React.createRef();
		this.Server = new Server();
		this.state = {
			Exit:this.props.Exit,
			small:this.props.small,
			absoluteUrl: this.Server.getAbsoluteUrl(),
			url: this.Server.getUrl(),
		}

	}
	componentDidMount() {
		this.setState({
			credit : this.props.credit
		  })
	  }


	render() {
		if (this.state.GotoLogin) {
			return <Redirect to={"/"} />;
		}
		if (this.state.GotoPage) {
			return <Redirect to={this.state.GotoPage} />;
		}
		return (
			this.props.noBack ?
			<div style={{display:'flex',justifyContent:'space-between',alignItems:'center',backgroundColor:this.props.bgColor||'#ebdd25',padding:10,height:this.props.height||'auto'}}>
				
				
				<div style={{width:'40%',display:'none'}}>
				  <Button className="YekanBakhFaMedium p-button-primary" onClick={this.LoginPress} style={{ textAlign: 'center', borderRadius: 15, width: '80%' }}> 
				  <span className="YekanBakhFaMedium" style={{ width: '100%', fontSize: 15 }} >خرید محصول</span> 
				  </Button>

				</div>

				
				<div style={{textAlign:'right',width:'100%'}}>
					<div className="YekanBakhFaMedium" style={{fontSize:14}}>  موجودی کیف پول مهر کارت :  {this.state.credit || 0} تومان</div> 
				</div>
				

			</div>
			:
			<div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',backgroundColor:this.props.bgColor||'#ebdd25',padding:10,height:(this.props.height)}}>
				
				
				<div>
					{!this.props.close ?
				<span style={{paddingRight:5}} className="fa fa-arrow-left" onClick={()=>{
					if(this.state.Exit){
						this.setState({
							GotoLogin:1
						})
					}else{
						window.history.back();
					}
				}}></span>
				:
				<span style={{paddingRight:5}} className="fas fa-window-close" onClick={()=>{
						this.setState({
							GotoPage:'/Home'
						})
				}}></span>

			}
				</div>
				<div style={{textAlign:'right'}}>
					<div className="YekanBakhFaMedium" style={{fontSize:this.state.small ? 16 : 26}}> {this.props.ComponentName}</div> 
				</div>
				

				
				

			</div>
			
		)
	}
}
function mapStateToProps(state) {        
	return {
	  username : state.username,
	  password : state.password,
	  ip : state.ip,
	  account:state.account,
	  place:state.place,
	  fullname : state.fullname,
	  mobile : state.mobile
	}
  }
  export default connect(mapStateToProps)(Header) 
